// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Home Inventory';

  @override
  String get settings => 'Settings';

  @override
  String get cancel => 'Cancel';

  @override
  String get save => 'Save';

  @override
  String get delete => 'Delete';

  @override
  String get optional => '(optional)';

  @override
  String get searchByProductName => 'Search by product name';

  @override
  String get barcodeScanSearch => 'Barcode scan search';

  @override
  String get barcodeScan => 'Barcode Scan';

  @override
  String get barcode => 'Barcode';

  @override
  String get rescan => 'Rescan';

  @override
  String get scannerHint => 'Align the barcode within the frame';

  @override
  String get enterBarcodeManually => 'Enter barcode manually';

  @override
  String get barcodeNumberOrSkip => 'Barcode number or skip';

  @override
  String get expirationWarning => 'Expiration Warning';

  @override
  String get expired => 'Expired';

  @override
  String get expiredStatus => 'Expired';

  @override
  String dDay(int days) {
    return 'D-$days';
  }

  @override
  String expiresOn(String date) {
    return 'Until $date';
  }

  @override
  String get noExpiration => 'No expiration';

  @override
  String get expirationDate => 'Expiration date';

  @override
  String get allProducts => 'All Products';

  @override
  String allProductsCount(int count) {
    return 'All Products $count';
  }

  @override
  String get addProduct => 'Add Product';

  @override
  String get newProduct => 'New Product';

  @override
  String get productName => 'Product Name';

  @override
  String get productNameHint => 'e.g. Whole Milk 1L';

  @override
  String get productNameManualHint => 'e.g. Apple, Potato, Onion';

  @override
  String get product => 'Product';

  @override
  String get editProduct => 'Edit Product';

  @override
  String get deleteProduct => 'Delete Product';

  @override
  String get productDetail => 'Product Detail';

  @override
  String get scanToRegister => 'Scan a barcode with camera to register';

  @override
  String get manualInput => 'Manual Input';

  @override
  String get manualInputDescription => 'Enter name and information manually';

  @override
  String get firstInventoryInfo => 'First inventory info';

  @override
  String get quantity => 'Quantity';

  @override
  String get storageLocation => 'Storage Location';

  @override
  String get selectLocation => 'Select';

  @override
  String get memo => 'Memo';

  @override
  String get memoHint => 'Store, purchase date, notes, etc.';

  @override
  String get addInventory => 'Add Inventory';

  @override
  String get newInventory => 'Add New Inventory';

  @override
  String get editInventory => 'Edit Inventory';

  @override
  String get inventoryItems => 'Inventory Items';

  @override
  String get deleteInventoryItem => 'Delete this inventory item';

  @override
  String get existingProductFound => 'Existing product found';

  @override
  String currentInventoryCount(int count) {
    return '$count inventory item(s)';
  }

  @override
  String totalInventory(int quantity, int count) {
    return 'Total: $quantity items ($count entries)';
  }

  @override
  String get deleteProductTitle => 'Delete Product';

  @override
  String deleteProductConfirm(String name) {
    return 'Delete $name?';
  }

  @override
  String deleteProductWarning(int count) {
    return '$count related inventory item(s) will also be deleted.';
  }

  @override
  String get deleteIrreversible => 'This action cannot be undone.';

  @override
  String get searchResults => 'Search Results';

  @override
  String searchResultsCount(int count) {
    return 'Search Results $count';
  }

  @override
  String inventoryCount(int count) {
    return '$count item(s)';
  }

  @override
  String get emptyStateTitle => 'No products registered';

  @override
  String get emptyStateBody =>
      'Press the ＋ button\nto register your first product';

  @override
  String get cameraPermissionDenied =>
      'Camera permission is required.\nPlease allow camera access to scan barcodes.';

  @override
  String get goToSettings => 'Go to Settings';

  @override
  String get cameraNotAvailable => 'Camera is not available on this device.';

  @override
  String get productNameRequired => 'Product name is required';

  @override
  String get productSaved => 'Product saved';

  @override
  String get inventoryAdded => 'Inventory added';

  @override
  String get registeredDate => 'Registered';

  @override
  String get productUpdated => 'Product updated';

  @override
  String get inventorySaved => 'Inventory saved';

  @override
  String get inventoryDeleted => 'Inventory item deleted';

  @override
  String get productDeleted => 'Product deleted';

  @override
  String get noInventoryItems => 'No inventory items';

  @override
  String get noInventoryItemsHint => 'Tap the button below to add inventory';

  @override
  String get deleteInventoryItemTitle => 'Delete Inventory Item';

  @override
  String get deleteInventoryItemConfirm => 'Delete this inventory item?';

  @override
  String get noSearchResults => 'No search results';

  @override
  String get productNotFoundRegister =>
      'Barcode not found. Register a new product.';
}
