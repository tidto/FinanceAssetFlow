import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_ko.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'generated/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('ko'),
  ];

  /// 앱 타이틀
  ///
  /// In ko, this message translates to:
  /// **'우리집 재고'**
  String get appTitle;

  /// No description provided for @settings.
  ///
  /// In ko, this message translates to:
  /// **'설정'**
  String get settings;

  /// No description provided for @cancel.
  ///
  /// In ko, this message translates to:
  /// **'취소'**
  String get cancel;

  /// No description provided for @save.
  ///
  /// In ko, this message translates to:
  /// **'저장'**
  String get save;

  /// No description provided for @delete.
  ///
  /// In ko, this message translates to:
  /// **'삭제'**
  String get delete;

  /// No description provided for @optional.
  ///
  /// In ko, this message translates to:
  /// **'(선택)'**
  String get optional;

  /// 검색바 플레이스홀더
  ///
  /// In ko, this message translates to:
  /// **'상품명으로 검색'**
  String get searchByProductName;

  /// No description provided for @barcodeScanSearch.
  ///
  /// In ko, this message translates to:
  /// **'바코드 스캔 검색'**
  String get barcodeScanSearch;

  /// No description provided for @barcodeScan.
  ///
  /// In ko, this message translates to:
  /// **'바코드 스캔'**
  String get barcodeScan;

  /// No description provided for @barcode.
  ///
  /// In ko, this message translates to:
  /// **'바코드'**
  String get barcode;

  /// No description provided for @rescan.
  ///
  /// In ko, this message translates to:
  /// **'다시 스캔'**
  String get rescan;

  /// No description provided for @scannerHint.
  ///
  /// In ko, this message translates to:
  /// **'바코드를 사각형 안에 맞춰주세요'**
  String get scannerHint;

  /// No description provided for @enterBarcodeManually.
  ///
  /// In ko, this message translates to:
  /// **'바코드 번호 직접 입력'**
  String get enterBarcodeManually;

  /// No description provided for @barcodeNumberOrSkip.
  ///
  /// In ko, this message translates to:
  /// **'바코드 번호 또는 생략'**
  String get barcodeNumberOrSkip;

  /// 홈 화면 임박/만료 경고 섹션 제목
  ///
  /// In ko, this message translates to:
  /// **'사용기한 주의'**
  String get expirationWarning;

  /// No description provided for @expired.
  ///
  /// In ko, this message translates to:
  /// **'기한 만료'**
  String get expired;

  /// No description provided for @expiredStatus.
  ///
  /// In ko, this message translates to:
  /// **'만료됨'**
  String get expiredStatus;

  /// No description provided for @dDay.
  ///
  /// In ko, this message translates to:
  /// **'D-{days}'**
  String dDay(int days);

  /// No description provided for @expiresOn.
  ///
  /// In ko, this message translates to:
  /// **'{date}까지'**
  String expiresOn(String date);

  /// No description provided for @noExpiration.
  ///
  /// In ko, this message translates to:
  /// **'무기한'**
  String get noExpiration;

  /// No description provided for @expirationDate.
  ///
  /// In ko, this message translates to:
  /// **'사용기한'**
  String get expirationDate;

  /// No description provided for @allProducts.
  ///
  /// In ko, this message translates to:
  /// **'전체 상품'**
  String get allProducts;

  /// No description provided for @allProductsCount.
  ///
  /// In ko, this message translates to:
  /// **'전체 상품 {count}'**
  String allProductsCount(int count);

  /// No description provided for @addProduct.
  ///
  /// In ko, this message translates to:
  /// **'상품 추가'**
  String get addProduct;

  /// No description provided for @newProduct.
  ///
  /// In ko, this message translates to:
  /// **'새 상품 등록'**
  String get newProduct;

  /// No description provided for @productName.
  ///
  /// In ko, this message translates to:
  /// **'상품명'**
  String get productName;

  /// No description provided for @productNameHint.
  ///
  /// In ko, this message translates to:
  /// **'예: 서울우유 1L'**
  String get productNameHint;

  /// No description provided for @productNameManualHint.
  ///
  /// In ko, this message translates to:
  /// **'예: 사과, 감자, 양파'**
  String get productNameManualHint;

  /// No description provided for @product.
  ///
  /// In ko, this message translates to:
  /// **'상품'**
  String get product;

  /// No description provided for @editProduct.
  ///
  /// In ko, this message translates to:
  /// **'상품 수정'**
  String get editProduct;

  /// No description provided for @deleteProduct.
  ///
  /// In ko, this message translates to:
  /// **'상품 삭제'**
  String get deleteProduct;

  /// No description provided for @productDetail.
  ///
  /// In ko, this message translates to:
  /// **'상품 상세'**
  String get productDetail;

  /// No description provided for @scanToRegister.
  ///
  /// In ko, this message translates to:
  /// **'카메라로 바코드를 촬영해 등록합니다'**
  String get scanToRegister;

  /// No description provided for @manualInput.
  ///
  /// In ko, this message translates to:
  /// **'직접 입력'**
  String get manualInput;

  /// No description provided for @manualInputDescription.
  ///
  /// In ko, this message translates to:
  /// **'이름과 정보를 수동으로 입력합니다'**
  String get manualInputDescription;

  /// No description provided for @firstInventoryInfo.
  ///
  /// In ko, this message translates to:
  /// **'첫 번째 재고 정보'**
  String get firstInventoryInfo;

  /// No description provided for @quantity.
  ///
  /// In ko, this message translates to:
  /// **'수량'**
  String get quantity;

  /// No description provided for @storageLocation.
  ///
  /// In ko, this message translates to:
  /// **'저장 위치'**
  String get storageLocation;

  /// No description provided for @selectLocation.
  ///
  /// In ko, this message translates to:
  /// **'선택하세요'**
  String get selectLocation;

  /// No description provided for @memo.
  ///
  /// In ko, this message translates to:
  /// **'메모'**
  String get memo;

  /// No description provided for @memoHint.
  ///
  /// In ko, this message translates to:
  /// **'구매처, 구매일, 특이사항 등'**
  String get memoHint;

  /// No description provided for @addInventory.
  ///
  /// In ko, this message translates to:
  /// **'재고 추가'**
  String get addInventory;

  /// No description provided for @newInventory.
  ///
  /// In ko, this message translates to:
  /// **'새 재고 추가'**
  String get newInventory;

  /// No description provided for @editInventory.
  ///
  /// In ko, this message translates to:
  /// **'재고 수정'**
  String get editInventory;

  /// No description provided for @inventoryItems.
  ///
  /// In ko, this message translates to:
  /// **'재고 항목'**
  String get inventoryItems;

  /// No description provided for @deleteInventoryItem.
  ///
  /// In ko, this message translates to:
  /// **'이 재고 항목 삭제'**
  String get deleteInventoryItem;

  /// No description provided for @existingProductFound.
  ///
  /// In ko, this message translates to:
  /// **'등록된 상품을 찾았습니다'**
  String get existingProductFound;

  /// No description provided for @currentInventoryCount.
  ///
  /// In ko, this message translates to:
  /// **'현재 재고 {count}건'**
  String currentInventoryCount(int count);

  /// No description provided for @totalInventory.
  ///
  /// In ko, this message translates to:
  /// **'총 재고 {quantity}개 ({count}건)'**
  String totalInventory(int quantity, int count);

  /// No description provided for @deleteProductTitle.
  ///
  /// In ko, this message translates to:
  /// **'상품 삭제'**
  String get deleteProductTitle;

  /// No description provided for @deleteProductConfirm.
  ///
  /// In ko, this message translates to:
  /// **'{name}을(를) 삭제하시겠습니까?'**
  String deleteProductConfirm(String name);

  /// No description provided for @deleteProductWarning.
  ///
  /// In ko, this message translates to:
  /// **'이 상품에 속한 재고 {count}건도 함께 삭제됩니다.'**
  String deleteProductWarning(int count);

  /// No description provided for @deleteIrreversible.
  ///
  /// In ko, this message translates to:
  /// **'이 작업은 되돌릴 수 없습니다.'**
  String get deleteIrreversible;

  /// No description provided for @searchResults.
  ///
  /// In ko, this message translates to:
  /// **'검색 결과'**
  String get searchResults;

  /// No description provided for @searchResultsCount.
  ///
  /// In ko, this message translates to:
  /// **'검색 결과 {count}'**
  String searchResultsCount(int count);

  /// No description provided for @inventoryCount.
  ///
  /// In ko, this message translates to:
  /// **'재고 {count}건'**
  String inventoryCount(int count);

  /// No description provided for @emptyStateTitle.
  ///
  /// In ko, this message translates to:
  /// **'등록된 상품이 없습니다'**
  String get emptyStateTitle;

  /// No description provided for @emptyStateBody.
  ///
  /// In ko, this message translates to:
  /// **'＋ 버튼을 눌러\n첫 번째 상품을 등록해보세요'**
  String get emptyStateBody;

  /// No description provided for @cameraPermissionDenied.
  ///
  /// In ko, this message translates to:
  /// **'카메라 권한이 필요합니다.\n바코드 스캔을 위해 카메라 접근을 허용해주세요.'**
  String get cameraPermissionDenied;

  /// No description provided for @goToSettings.
  ///
  /// In ko, this message translates to:
  /// **'설정으로 이동'**
  String get goToSettings;

  /// No description provided for @cameraNotAvailable.
  ///
  /// In ko, this message translates to:
  /// **'이 기기에서 카메라를 사용할 수 없습니다.'**
  String get cameraNotAvailable;

  /// No description provided for @productNameRequired.
  ///
  /// In ko, this message translates to:
  /// **'상품명을 입력해주세요'**
  String get productNameRequired;

  /// No description provided for @productSaved.
  ///
  /// In ko, this message translates to:
  /// **'상품이 저장되었습니다'**
  String get productSaved;

  /// No description provided for @inventoryAdded.
  ///
  /// In ko, this message translates to:
  /// **'재고가 추가되었습니다'**
  String get inventoryAdded;

  /// No description provided for @registeredDate.
  ///
  /// In ko, this message translates to:
  /// **'등록일'**
  String get registeredDate;

  /// No description provided for @productUpdated.
  ///
  /// In ko, this message translates to:
  /// **'상품이 수정되었습니다'**
  String get productUpdated;

  /// No description provided for @inventorySaved.
  ///
  /// In ko, this message translates to:
  /// **'재고가 저장되었습니다'**
  String get inventorySaved;

  /// No description provided for @inventoryDeleted.
  ///
  /// In ko, this message translates to:
  /// **'재고 항목이 삭제되었습니다'**
  String get inventoryDeleted;

  /// No description provided for @productDeleted.
  ///
  /// In ko, this message translates to:
  /// **'상품이 삭제되었습니다'**
  String get productDeleted;

  /// No description provided for @noInventoryItems.
  ///
  /// In ko, this message translates to:
  /// **'재고 항목이 없습니다'**
  String get noInventoryItems;

  /// No description provided for @noInventoryItemsHint.
  ///
  /// In ko, this message translates to:
  /// **'아래 버튼을 눌러 재고를 추가하세요'**
  String get noInventoryItemsHint;

  /// No description provided for @deleteInventoryItemTitle.
  ///
  /// In ko, this message translates to:
  /// **'재고 항목 삭제'**
  String get deleteInventoryItemTitle;

  /// No description provided for @deleteInventoryItemConfirm.
  ///
  /// In ko, this message translates to:
  /// **'이 재고 항목을 삭제하시겠습니까?'**
  String get deleteInventoryItemConfirm;

  /// 검색 결과 0건일 때 메시지
  ///
  /// In ko, this message translates to:
  /// **'검색 결과가 없습니다'**
  String get noSearchResults;

  /// 바코드 스캔 후 상품 미존재 시 스낵바 메시지
  ///
  /// In ko, this message translates to:
  /// **'등록되지 않은 바코드입니다. 새 상품을 등록하세요.'**
  String get productNotFoundRegister;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'ko'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'ko':
      return AppLocalizationsKo();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
