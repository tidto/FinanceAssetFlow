// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Korean (`ko`).
class AppLocalizationsKo extends AppLocalizations {
  AppLocalizationsKo([String locale = 'ko']) : super(locale);

  @override
  String get appTitle => '우리집 재고';

  @override
  String get settings => '설정';

  @override
  String get cancel => '취소';

  @override
  String get save => '저장';

  @override
  String get delete => '삭제';

  @override
  String get optional => '(선택)';

  @override
  String get searchByProductName => '상품명으로 검색';

  @override
  String get barcodeScanSearch => '바코드 스캔 검색';

  @override
  String get barcodeScan => '바코드 스캔';

  @override
  String get barcode => '바코드';

  @override
  String get rescan => '다시 스캔';

  @override
  String get scannerHint => '바코드를 사각형 안에 맞춰주세요';

  @override
  String get enterBarcodeManually => '바코드 번호 직접 입력';

  @override
  String get barcodeNumberOrSkip => '바코드 번호 또는 생략';

  @override
  String get expirationWarning => '사용기한 주의';

  @override
  String get expired => '기한 만료';

  @override
  String get expiredStatus => '만료됨';

  @override
  String dDay(int days) {
    return 'D-$days';
  }

  @override
  String expiresOn(String date) {
    return '$date까지';
  }

  @override
  String get noExpiration => '무기한';

  @override
  String get expirationDate => '사용기한';

  @override
  String get allProducts => '전체 상품';

  @override
  String allProductsCount(int count) {
    return '전체 상품 $count';
  }

  @override
  String get addProduct => '상품 추가';

  @override
  String get newProduct => '새 상품 등록';

  @override
  String get productName => '상품명';

  @override
  String get productNameHint => '예: 서울우유 1L';

  @override
  String get productNameManualHint => '예: 사과, 감자, 양파';

  @override
  String get product => '상품';

  @override
  String get editProduct => '상품 수정';

  @override
  String get deleteProduct => '상품 삭제';

  @override
  String get productDetail => '상품 상세';

  @override
  String get scanToRegister => '카메라로 바코드를 촬영해 등록합니다';

  @override
  String get manualInput => '직접 입력';

  @override
  String get manualInputDescription => '이름과 정보를 수동으로 입력합니다';

  @override
  String get firstInventoryInfo => '첫 번째 재고 정보';

  @override
  String get quantity => '수량';

  @override
  String get storageLocation => '저장 위치';

  @override
  String get selectLocation => '선택하세요';

  @override
  String get memo => '메모';

  @override
  String get memoHint => '구매처, 구매일, 특이사항 등';

  @override
  String get addInventory => '재고 추가';

  @override
  String get newInventory => '새 재고 추가';

  @override
  String get editInventory => '재고 수정';

  @override
  String get inventoryItems => '재고 항목';

  @override
  String get deleteInventoryItem => '이 재고 항목 삭제';

  @override
  String get existingProductFound => '등록된 상품을 찾았습니다';

  @override
  String currentInventoryCount(int count) {
    return '현재 재고 $count건';
  }

  @override
  String totalInventory(int quantity, int count) {
    return '총 재고 $quantity개 ($count건)';
  }

  @override
  String get deleteProductTitle => '상품 삭제';

  @override
  String deleteProductConfirm(String name) {
    return '$name을(를) 삭제하시겠습니까?';
  }

  @override
  String deleteProductWarning(int count) {
    return '이 상품에 속한 재고 $count건도 함께 삭제됩니다.';
  }

  @override
  String get deleteIrreversible => '이 작업은 되돌릴 수 없습니다.';

  @override
  String get searchResults => '검색 결과';

  @override
  String searchResultsCount(int count) {
    return '검색 결과 $count';
  }

  @override
  String inventoryCount(int count) {
    return '재고 $count건';
  }

  @override
  String get emptyStateTitle => '등록된 상품이 없습니다';

  @override
  String get emptyStateBody => '＋ 버튼을 눌러\n첫 번째 상품을 등록해보세요';

  @override
  String get cameraPermissionDenied =>
      '카메라 권한이 필요합니다.\n바코드 스캔을 위해 카메라 접근을 허용해주세요.';

  @override
  String get goToSettings => '설정으로 이동';

  @override
  String get cameraNotAvailable => '이 기기에서 카메라를 사용할 수 없습니다.';

  @override
  String get productNameRequired => '상품명을 입력해주세요';

  @override
  String get productSaved => '상품이 저장되었습니다';

  @override
  String get inventoryAdded => '재고가 추가되었습니다';

  @override
  String get registeredDate => '등록일';

  @override
  String get productUpdated => '상품이 수정되었습니다';

  @override
  String get inventorySaved => '재고가 저장되었습니다';

  @override
  String get inventoryDeleted => '재고 항목이 삭제되었습니다';

  @override
  String get productDeleted => '상품이 삭제되었습니다';

  @override
  String get noInventoryItems => '재고 항목이 없습니다';

  @override
  String get noInventoryItemsHint => '아래 버튼을 눌러 재고를 추가하세요';

  @override
  String get deleteInventoryItemTitle => '재고 항목 삭제';

  @override
  String get deleteInventoryItemConfirm => '이 재고 항목을 삭제하시겠습니까?';

  @override
  String get noSearchResults => '검색 결과가 없습니다';

  @override
  String get productNotFoundRegister => '등록되지 않은 바코드입니다. 새 상품을 등록하세요.';
}
