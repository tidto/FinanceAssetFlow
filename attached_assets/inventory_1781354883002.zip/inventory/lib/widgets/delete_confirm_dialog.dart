import 'package:flutter/material.dart';

import '../l10n/generated/app_localizations.dart';

/// A confirmation dialog for deleting a product and its associated inventory.
class DeleteConfirmDialog extends StatelessWidget {
  const DeleteConfirmDialog._({
    required this.productName,
    required this.inventoryCount,
  });

  /// Name of the product to delete.
  final String productName;

  /// Number of inventory items that will be deleted along with the product.
  final int inventoryCount;

  /// Shows the dialog and returns true if the user confirmed deletion.
  static Future<bool> show(
    BuildContext context, {
    required String productName,
    required int inventoryCount,
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => DeleteConfirmDialog._(
        productName: productName,
        inventoryCount: inventoryCount,
      ),
    );
    return result ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    return AlertDialog(
      title: Text(l10n.deleteProductTitle),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(l10n.deleteProductConfirm(productName)),
          if (inventoryCount > 0) ...[
            const SizedBox(height: 8),
            Text(
              l10n.deleteProductWarning(inventoryCount),
              style: TextStyle(color: theme.colorScheme.error),
            ),
          ],
          const SizedBox(height: 8),
          Text(
            l10n.deleteIrreversible,
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(false),
          child: Text(l10n.cancel),
        ),
        FilledButton(
          onPressed: () => Navigator.of(context).pop(true),
          style: FilledButton.styleFrom(
            backgroundColor: theme.colorScheme.error,
            foregroundColor: theme.colorScheme.onError,
          ),
          child: Text(l10n.delete),
        ),
      ],
    );
  }
}
