import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../l10n/generated/app_localizations.dart';
import '../providers/storage_location_provider.dart';

/// A dropdown widget that lists all storage locations from the database.
class StorageLocationPicker extends ConsumerWidget {
  const StorageLocationPicker({
    super.key,
    required this.value,
    required this.onChanged,
  });

  /// Currently selected storage location id, or null if none selected.
  final int? value;

  /// Called when the user selects a location.
  final ValueChanged<int?> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final locationsAsync = ref.watch(storageLocationsProvider);

    return locationsAsync.when(
      data: (locations) {
        return DropdownButtonFormField<int?>(
          initialValue: value,
          decoration: InputDecoration(
            labelText: l10n.storageLocation,
            border: const OutlineInputBorder(),
          ),
          isExpanded: true,
          items: [
            DropdownMenuItem<int?>(
              value: null,
              child: Text(
                l10n.selectLocation,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            ...locations.map(
              (location) => DropdownMenuItem<int?>(
                value: location.id,
                child: Text(location.name),
              ),
            ),
          ],
          onChanged: onChanged,
        );
      },
      loading: () => DropdownButtonFormField<int?>(
        initialValue: null,
        decoration: InputDecoration(
          labelText: l10n.storageLocation,
          border: const OutlineInputBorder(),
        ),
        items: const [],
        onChanged: null,
      ),
      error: (_, _) => DropdownButtonFormField<int?>(
        initialValue: null,
        decoration: InputDecoration(
          labelText: l10n.storageLocation,
          border: const OutlineInputBorder(),
        ),
        items: const [],
        onChanged: null,
      ),
    );
  }
}
