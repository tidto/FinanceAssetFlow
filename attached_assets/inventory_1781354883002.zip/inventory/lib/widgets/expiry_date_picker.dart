import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../l10n/generated/app_localizations.dart';

/// A widget that allows selecting an expiration date or toggling "no expiration".
class ExpiryDatePicker extends StatelessWidget {
  const ExpiryDatePicker({
    super.key,
    required this.value,
    required this.onChanged,
  });

  /// Current expiration date. Null means no expiration.
  final DateTime? value;

  /// Called when the date changes. Null means no expiration was toggled on.
  final ValueChanged<DateTime?> onChanged;

  bool get _isNoExpiration => value == null;

  Future<void> _pickDate(BuildContext context) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: value ?? now,
      firstDate: now.subtract(const Duration(days: 365)),
      lastDate: now.add(const Duration(days: 365 * 10)),
    );
    if (picked != null) {
      onChanged(picked);
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final dateFormat = DateFormat.yMd();

    return Row(
      children: [
        // Date display field
        Expanded(
          child: GestureDetector(
            onTap: _isNoExpiration ? null : () => _pickDate(context),
            child: InputDecorator(
              decoration: InputDecoration(
                labelText: l10n.expirationDate,
                border: const OutlineInputBorder(),
                enabled: !_isNoExpiration,
                suffixIcon: const Icon(Icons.calendar_today, size: 20),
              ),
              child: Text(
                _isNoExpiration
                    ? l10n.noExpiration
                    : (value != null ? dateFormat.format(value!) : ''),
                style: theme.textTheme.bodyLarge?.copyWith(
                  color: _isNoExpiration
                      ? theme.colorScheme.onSurfaceVariant
                      : null,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // No-expiration toggle
        Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              l10n.noExpiration,
              style: theme.textTheme.labelSmall,
            ),
            Switch(
              value: _isNoExpiration,
              onChanged: (noExpiration) {
                if (noExpiration) {
                  onChanged(null);
                } else {
                  onChanged(DateTime.now());
                }
              },
            ),
          ],
        ),
      ],
    );
  }
}
