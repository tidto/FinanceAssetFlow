import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

/// A stepper widget with decrement/increment buttons and a direct numeric input
/// field in the center.
class QuantityStepper extends StatefulWidget {
  const QuantityStepper({
    super.key,
    required this.value,
    required this.onChanged,
    this.min = 0,
    this.max,
    this.compact = false,
  });

  /// Current quantity value.
  final int value;

  /// Called when the value changes (via buttons or direct input).
  final ValueChanged<int> onChanged;

  /// Minimum allowed value (defaults to 0).
  final int min;

  /// Maximum allowed value (null means unlimited).
  final int? max;

  /// When true, uses smaller buttons (32x32) and narrower input area.
  final bool compact;

  @override
  State<QuantityStepper> createState() => _QuantityStepperState();
}

class _QuantityStepperState extends State<QuantityStepper> {
  late TextEditingController _controller;
  late FocusNode _focusNode;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.value.toString());
    _focusNode = FocusNode();
    _focusNode.addListener(_onFocusChanged);
  }

  @override
  void didUpdateWidget(covariant QuantityStepper oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.value != widget.value && !_focusNode.hasFocus) {
      _controller.text = widget.value.toString();
    }
  }

  @override
  void dispose() {
    _focusNode.removeListener(_onFocusChanged);
    _focusNode.dispose();
    _controller.dispose();
    super.dispose();
  }

  void _onFocusChanged() {
    if (!_focusNode.hasFocus) {
      _commitTextValue();
    }
  }

  void _commitTextValue() {
    final text = _controller.text.trim();
    var parsed = int.tryParse(text);
    if (parsed == null) {
      // Reset to current value on invalid input.
      _controller.text = widget.value.toString();
      return;
    }
    if (parsed < widget.min) {
      parsed = widget.min;
    }
    if (widget.max != null && parsed > widget.max!) {
      parsed = widget.max;
    }
    _controller.text = parsed.toString();
    if (parsed != widget.value) {
      widget.onChanged(parsed!);
    }
  }

  void _decrement() {
    final newValue = widget.value - 1;
    if (newValue >= widget.min) {
      widget.onChanged(newValue);
    }
  }

  void _increment() {
    if (widget.max == null || widget.value < widget.max!) {
      widget.onChanged(widget.value + 1);
    }
  }

  bool get _canDecrement => widget.value > widget.min;
  bool get _canIncrement => widget.max == null || widget.value < widget.max!;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final buttonSize = widget.compact ? 32.0 : 44.0;
    final iconSize = widget.compact ? 18.0 : 24.0;
    final inputWidth = widget.compact ? 48.0 : 64.0;

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: theme.colorScheme.outlineVariant),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Decrement button
          SizedBox(
            width: buttonSize,
            height: buttonSize,
            child: IconButton(
              onPressed: _canDecrement ? _decrement : null,
              icon: Icon(Icons.remove, size: iconSize),
              padding: EdgeInsets.zero,
              style: IconButton.styleFrom(
                shape: const CircleBorder(),
              ),
            ),
          ),
          // Numeric input
          SizedBox(
            width: inputWidth,
            child: TextFormField(
              controller: _controller,
              focusNode: _focusNode,
              keyboardType: TextInputType.number,
              textAlign: TextAlign.center,
              inputFormatters: [
                FilteringTextInputFormatter.digitsOnly,
              ],
              decoration: const InputDecoration(
                border: InputBorder.none,
                contentPadding: EdgeInsets.zero,
                isDense: true,
              ),
              style: theme.textTheme.bodyLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
              onFieldSubmitted: (_) => _commitTextValue(),
            ),
          ),
          // Increment button
          SizedBox(
            width: buttonSize,
            height: buttonSize,
            child: IconButton(
              onPressed: _canIncrement ? _increment : null,
              icon: Icon(Icons.add, size: iconSize),
              padding: EdgeInsets.zero,
              style: IconButton.styleFrom(
                shape: const CircleBorder(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
