import 'package:go_router/go_router.dart';
import 'package:inventory/screens/home/home_screen.dart';
import 'package:inventory/screens/inventory/inventory_item_form_screen.dart';
import 'package:inventory/screens/product/product_detail_screen.dart';
import 'package:inventory/screens/product/product_form_screen.dart';
import 'package:inventory/screens/scanner/barcode_scan_screen.dart';

/// Application route paths.
abstract class AppRoutes {
  static const home = '/';
  static const scan = '/scan';
  static const productNew = '/product/new';

  static String productDetail(String id) => '/product/$id';
  static String productEdit(String id) => '/product/$id/edit';
  static String inventoryNew(String productId) =>
      '/product/$productId/inventory/new';
  static String inventoryEdit(String productId, String itemId) =>
      '/product/$productId/inventory/$itemId/edit';
}

final appRouter = GoRouter(
  initialLocation: AppRoutes.home,
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const HomeScreen(),
    ),
    GoRoute(
      path: '/scan',
      builder: (context, state) => const BarcodeScanScreen(),
    ),
    GoRoute(
      path: '/product/new',
      builder: (context, state) {
        final barcode = state.uri.queryParameters['barcode'];
        return ProductFormScreen(barcode: barcode);
      },
    ),
    GoRoute(
      path: '/product/:id',
      builder: (context, state) {
        final id = int.parse(state.pathParameters['id']!);
        return ProductDetailScreen(productId: id);
      },
      routes: [
        GoRoute(
          path: 'edit',
          builder: (context, state) {
            final id = int.parse(state.pathParameters['id']!);
            return ProductFormScreen(editProductId: id);
          },
        ),
        GoRoute(
          path: 'inventory/new',
          builder: (context, state) {
            final id = int.parse(state.pathParameters['id']!);
            return InventoryItemFormScreen(productId: id);
          },
        ),
        GoRoute(
          path: 'inventory/:itemId/edit',
          builder: (context, state) {
            final id = int.parse(state.pathParameters['id']!);
            final itemId = int.parse(state.pathParameters['itemId']!);
            return InventoryItemFormScreen(
              productId: id,
              itemId: itemId,
            );
          },
        ),
      ],
    ),
  ],
);
