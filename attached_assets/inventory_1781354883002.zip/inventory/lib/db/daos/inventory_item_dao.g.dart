// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'inventory_item_dao.dart';

// ignore_for_file: type=lint
mixin _$InventoryItemDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProductsTable get products => attachedDatabase.products;
  $StorageLocationsTable get storageLocations =>
      attachedDatabase.storageLocations;
  $InventoryItemsTable get inventoryItems => attachedDatabase.inventoryItems;
}
