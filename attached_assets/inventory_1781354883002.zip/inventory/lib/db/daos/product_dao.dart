import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables/inventory_items_table.dart';
import '../tables/products_table.dart';

part 'product_dao.g.dart';

@DriftAccessor(tables: [Products, InventoryItems])
class ProductDao extends DatabaseAccessor<AppDatabase> with _$ProductDaoMixin {
  ProductDao(super.db);

  Stream<List<Product>> getAllProducts() {
    return (select(products)..orderBy([(t) => OrderingTerm.asc(t.name)]))
        .watch();
  }

  Future<Product?> getProductById(int id) {
    return (select(products)..where((t) => t.id.equals(id))).getSingleOrNull();
  }

  Future<Product?> getProductByBarcode(String barcode) {
    return (select(products)..where((t) => t.barcode.equals(barcode)))
        .getSingleOrNull();
  }

  Future<List<Product>> searchProductsByName(String query) {
    return (select(products)..where((t) => t.name.like('%$query%'))).get();
  }

  Future<int> insertProduct(ProductsCompanion product) {
    return into(products).insert(product);
  }

  Future<bool> updateProduct(ProductsCompanion product) {
    return update(products).replace(Product(
      id: product.id.value,
      barcode: product.barcode.value,
      name: product.name.value,
      createdAt: product.createdAt.value,
      updatedAt: product.updatedAt.value,
    ));
  }

  Future<int> deleteProduct(int id) {
    return (delete(products)..where((t) => t.id.equals(id))).go();
  }

  Stream<List<ProductWithTotalQuantity>> getProductsWithTotalQuantity() {
    final totalQuantity = inventoryItems.quantity.sum();

    final query = select(products).join([
      leftOuterJoin(
        inventoryItems,
        inventoryItems.productId.equalsExp(products.id),
      ),
    ]);

    query
      ..addColumns([totalQuantity])
      ..groupBy([products.id])
      ..orderBy([OrderingTerm.asc(products.name)]);

    return query.watch().map((rows) {
      return rows.map((row) {
        return ProductWithTotalQuantity(
          product: row.readTable(products),
          totalQuantity: row.read(totalQuantity) ?? 0,
        );
      }).toList();
    });
  }
}

class ProductWithTotalQuantity {
  final Product product;
  final int totalQuantity;

  ProductWithTotalQuantity({
    required this.product,
    required this.totalQuantity,
  });
}
