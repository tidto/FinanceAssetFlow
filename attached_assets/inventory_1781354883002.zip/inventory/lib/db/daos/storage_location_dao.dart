import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables/storage_locations_table.dart';

part 'storage_location_dao.g.dart';

@DriftAccessor(tables: [StorageLocations])
class StorageLocationDao extends DatabaseAccessor<AppDatabase>
    with _$StorageLocationDaoMixin {
  StorageLocationDao(super.db);

  Stream<List<StorageLocation>> getAllLocations() {
    return (select(storageLocations)
          ..orderBy([(t) => OrderingTerm.asc(t.id)]))
        .watch();
  }

  Future<int> insertLocation(String name) {
    return into(storageLocations).insert(
      StorageLocationsCompanion.insert(
        name: name,
        createdAt: DateTime.now(),
      ),
    );
  }

  Future<int> deleteLocation(int id) {
    return (delete(storageLocations)..where((t) => t.id.equals(id))).go();
  }
}
