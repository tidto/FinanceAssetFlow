import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables/inventory_items_table.dart';

part 'inventory_item_dao.g.dart';

@DriftAccessor(tables: [InventoryItems])
class InventoryItemDao extends DatabaseAccessor<AppDatabase>
    with _$InventoryItemDaoMixin {
  InventoryItemDao(super.db);

  Stream<List<InventoryItem>> getItemsByProductId(int productId) {
    return (select(inventoryItems)
          ..where((t) => t.productId.equals(productId))
          ..orderBy([(t) => OrderingTerm.asc(t.expirationDate)]))
        .watch();
  }

  Future<InventoryItem?> getItemById(int id) {
    return (select(inventoryItems)..where((t) => t.id.equals(id)))
        .getSingleOrNull();
  }

  Stream<List<InventoryItem>> getExpiringItems(int alertDays) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final alertDate = today.add(Duration(days: alertDays));

    return (select(inventoryItems)
          ..where((t) =>
              t.expirationDate.isNotNull() &
              t.expirationDate.isBiggerOrEqualValue(today) &
              t.expirationDate.isSmallerOrEqualValue(alertDate) &
              t.quantity.isBiggerThanValue(0))
          ..orderBy([(t) => OrderingTerm.asc(t.expirationDate)]))
        .watch();
  }

  Stream<List<InventoryItem>> getExpiredItems() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    return (select(inventoryItems)
          ..where((t) =>
              t.expirationDate.isNotNull() &
              t.expirationDate.isSmallerThanValue(today) &
              t.quantity.isBiggerThanValue(0))
          ..orderBy([(t) => OrderingTerm.asc(t.expirationDate)]))
        .watch();
  }

  Future<int> insertItem(InventoryItemsCompanion item) {
    return into(inventoryItems).insert(item);
  }

  Future<bool> updateItem(InventoryItemsCompanion item) {
    return update(inventoryItems).replace(InventoryItem(
      id: item.id.value,
      productId: item.productId.value,
      quantity: item.quantity.value,
      expirationDate: item.expirationDate.value,
      memo: item.memo.value,
      storageLocationId: item.storageLocationId.value,
      createdAt: item.createdAt.value,
      updatedAt: item.updatedAt.value,
    ));
  }

  Future<bool> updateQuantity(int id, int quantity) {
    return (update(inventoryItems)..where((t) => t.id.equals(id))).write(
      InventoryItemsCompanion(
        quantity: Value(quantity),
        updatedAt: Value(DateTime.now()),
      ),
    ).then((rows) => rows > 0);
  }

  Future<int> deleteItem(int id) {
    return (delete(inventoryItems)..where((t) => t.id.equals(id))).go();
  }

  Future<int> getTotalQuantityByProductId(int productId) async {
    final totalQuantity = inventoryItems.quantity.sum();
    final query = selectOnly(inventoryItems)
      ..addColumns([totalQuantity])
      ..where(inventoryItems.productId.equals(productId));

    final result = await query.getSingle();
    return result.read(totalQuantity) ?? 0;
  }
}
