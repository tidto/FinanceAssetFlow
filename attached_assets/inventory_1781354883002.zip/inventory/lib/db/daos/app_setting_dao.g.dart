// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_setting_dao.dart';

// ignore_for_file: type=lint
mixin _$AppSettingDaoMixin on DatabaseAccessor<AppDatabase> {
  $AppSettingsTable get appSettings => attachedDatabase.appSettings;
}
