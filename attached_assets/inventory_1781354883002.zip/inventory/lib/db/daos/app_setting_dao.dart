import 'package:drift/drift.dart';

import '../app_database.dart';
import '../tables/app_settings_table.dart';

part 'app_setting_dao.g.dart';

@DriftAccessor(tables: [AppSettings])
class AppSettingDao extends DatabaseAccessor<AppDatabase>
    with _$AppSettingDaoMixin {
  AppSettingDao(super.db);

  Future<String?> getValue(String key) async {
    final result = await (select(appSettings)
          ..where((t) => t.key.equals(key)))
        .getSingleOrNull();
    return result?.value;
  }

  Future<void> setValue(String key, String value) {
    return into(appSettings).insertOnConflictUpdate(
      AppSettingsCompanion.insert(
        key: key,
        value: value,
      ),
    );
  }
}
