import 'package:drift/drift.dart';

import 'products_table.dart';
import 'storage_locations_table.dart';

class InventoryItems extends Table {
  IntColumn get id => integer().autoIncrement()();
  IntColumn get productId =>
      integer().references(Products, #id, onDelete: KeyAction.cascade)();
  IntColumn get quantity => integer()
      .customConstraint('NOT NULL DEFAULT 1 CHECK(quantity >= 0)')();
  DateTimeColumn get expirationDate => dateTime().nullable()();
  TextColumn get memo => text().nullable()();
  IntColumn get storageLocationId =>
      integer().nullable().references(StorageLocations, #id)();
  DateTimeColumn get createdAt => dateTime()();
  DateTimeColumn get updatedAt => dateTime()();
}
