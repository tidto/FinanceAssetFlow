import 'dart:io';

import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import 'daos/app_setting_dao.dart';
import 'daos/inventory_item_dao.dart';
import 'daos/product_dao.dart';
import 'daos/storage_location_dao.dart';
import 'tables/app_settings_table.dart';
import 'tables/inventory_items_table.dart';
import 'tables/products_table.dart';
import 'tables/storage_locations_table.dart';

part 'app_database.g.dart';

@DriftDatabase(
  tables: [Products, InventoryItems, StorageLocations, AppSettings],
  daos: [ProductDao, InventoryItemDao, StorageLocationDao, AppSettingDao],
)
class AppDatabase extends _$AppDatabase {
  AppDatabase() : super(_openConnection());

  AppDatabase.forTesting(super.e);

  @override
  int get schemaVersion => 1;

  @override
  MigrationStrategy get migration {
    return MigrationStrategy(
      beforeOpen: (details) async {
        await customStatement('PRAGMA foreign_keys = ON');
      },
      onCreate: (Migrator m) async {
        await m.createAll();
        await _seedData();
      },
    );
  }

  Future<void> _seedData() async {
    final now = DateTime.now();

    const locationNames = [
      '냉장고',
      '냉동고',
      '김치냉장고',
      '창고',
      '펜트리',
      '발코니',
      '세탁실',
      '보일러실',
      '욕실',
      '안방',
      '신발장',
      '화장대',
      '책상',
      '싱크대',
      '옷장',
      '서랍장',
      '서재',
      '드레스룸',
      '아이방',
      '거실',
      '주방',
      '현관',
      '다용도실',
      '다락방',
      '지하실',
      '차고',
      '마당',
      '기타',
    ];

    for (final name in locationNames) {
      await into(storageLocations).insert(
        StorageLocationsCompanion.insert(
          name: name,
          createdAt: now,
        ),
      );
    }

    await into(appSettings).insert(
      AppSettingsCompanion.insert(
        key: 'expiration_alert_days',
        value: '3',
      ),
    );
  }
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dbFolder = await getApplicationDocumentsDirectory();
    final file = File(p.join(dbFolder.path, 'inventory.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}
