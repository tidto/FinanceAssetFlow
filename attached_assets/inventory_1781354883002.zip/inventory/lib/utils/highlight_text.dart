import 'package:flutter/material.dart';

/// Builds a list of [TextSpan] segments that highlight all occurrences of
/// [query] within [text].
///
/// The matching is case-insensitive. Matched portions are rendered with a
/// light blue background (#dbeafe) and bold weight.
///
/// Returns a single un-styled span wrapping the full [text] when [query]
/// is empty or not found.
List<TextSpan> highlightText({
  required String text,
  required String query,
  TextStyle? baseStyle,
  TextStyle? highlightStyle,
}) {
  if (query.isEmpty) {
    return [TextSpan(text: text, style: baseStyle)];
  }

  final lowerText = text.toLowerCase();
  final lowerQuery = query.toLowerCase();

  final spans = <TextSpan>[];
  int start = 0;

  while (true) {
    final index = lowerText.indexOf(lowerQuery, start);
    if (index == -1) {
      // Remaining text after last match.
      if (start < text.length) {
        spans.add(TextSpan(text: text.substring(start), style: baseStyle));
      }
      break;
    }

    // Text before the match.
    if (index > start) {
      spans.add(TextSpan(text: text.substring(start, index), style: baseStyle));
    }

    // The matched portion.
    final effectiveHighlight = highlightStyle ??
        (baseStyle ?? const TextStyle()).copyWith(
          backgroundColor: const Color(0xFFDBEAFE),
          fontWeight: FontWeight.w700,
        );

    spans.add(
      TextSpan(
        text: text.substring(index, index + query.length),
        style: effectiveHighlight,
      ),
    );

    start = index + query.length;
  }

  if (spans.isEmpty) {
    return [TextSpan(text: text, style: baseStyle)];
  }

  return spans;
}
