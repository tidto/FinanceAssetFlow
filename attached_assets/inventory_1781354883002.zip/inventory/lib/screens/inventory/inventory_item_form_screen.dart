import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../db/app_database.dart';
import '../../l10n/generated/app_localizations.dart';
import '../../providers/database_provider.dart';
import '../../providers/inventory_provider.dart';
import '../../widgets/expiry_date_picker.dart';
import '../../widgets/quantity_stepper.dart';
import '../../widgets/storage_location_picker.dart';

/// Screen for adding or editing an inventory item.
///
/// - Add mode: `itemId` is null, creates a new inventory item for `productId`.
/// - Edit mode: `itemId` is set, loads existing item and allows editing/deleting.
class InventoryItemFormScreen extends ConsumerStatefulWidget {
  const InventoryItemFormScreen({
    super.key,
    required this.productId,
    this.itemId,
  });

  final int productId;
  final int? itemId;

  bool get isEditMode => itemId != null;

  @override
  ConsumerState<InventoryItemFormScreen> createState() =>
      _InventoryItemFormScreenState();
}

class _InventoryItemFormScreenState
    extends ConsumerState<InventoryItemFormScreen> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController _memoController;
  int _quantity = 1;
  DateTime? _expirationDate;
  int? _storageLocationId;

  bool _isLoading = true;
  bool _isSaving = false;
  InventoryItem? _existingItem;

  @override
  void initState() {
    super.initState();
    _memoController = TextEditingController();

    if (widget.isEditMode) {
      _loadExistingItem();
    } else {
      _isLoading = false;
    }
  }

  @override
  void dispose() {
    _memoController.dispose();
    super.dispose();
  }

  Future<void> _loadExistingItem() async {
    try {
      final dao = ref.read(inventoryItemDaoProvider);
      final item = await dao.getItemById(widget.itemId!);
      if (item != null && mounted) {
        setState(() {
          _existingItem = item;
          _quantity = item.quantity;
          _expirationDate = item.expirationDate;
          _storageLocationId = item.storageLocationId;
          _memoController.text = item.memo ?? '';
          _isLoading = false;
        });
      } else if (mounted) {
        setState(() => _isLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);
    try {
      final actions = ref.read(inventoryActionsProvider);
      final memoText = _memoController.text.trim();

      if (widget.isEditMode && _existingItem != null) {
        await actions.update(
          id: _existingItem!.id,
          productId: widget.productId,
          quantity: _quantity,
          expirationDate: _expirationDate,
          storageLocationId: _storageLocationId,
          memo: memoText.isEmpty ? null : memoText,
          createdAt: _existingItem!.createdAt,
        );
      } else {
        await actions.create(
          productId: widget.productId,
          quantity: _quantity,
          expirationDate: _expirationDate,
          storageLocationId: _storageLocationId,
          memo: memoText.isEmpty ? null : memoText,
        );
      }

      if (mounted) {
        final l10n = AppLocalizations.of(context)!;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              widget.isEditMode ? l10n.inventorySaved : l10n.inventoryAdded,
            ),
          ),
        );
        context.pop();
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  Future<void> _deleteItem() async {
    final l10n = AppLocalizations.of(context)!;

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.deleteInventoryItemTitle),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(l10n.deleteInventoryItemConfirm),
            const SizedBox(height: 8),
            Text(
              l10n.deleteIrreversible,
              style: Theme.of(dialogContext).textTheme.bodySmall?.copyWith(
                    color: Theme.of(dialogContext)
                        .colorScheme
                        .onSurfaceVariant,
                  ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            style: FilledButton.styleFrom(
              backgroundColor:
                  Theme.of(dialogContext).colorScheme.error,
              foregroundColor:
                  Theme.of(dialogContext).colorScheme.onError,
            ),
            child: Text(l10n.delete),
          ),
        ],
      ),
    );

    if (confirmed == true && mounted) {
      await ref
          .read(inventoryActionsProvider)
          .delete(_existingItem!.id, widget.productId);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.inventoryDeleted)),
        );
        context.pop();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(
          title: Text(
              widget.isEditMode ? l10n.editInventory : l10n.newInventory),
        ),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(
            widget.isEditMode ? l10n.editInventory : l10n.newInventory),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Quantity
            Row(
              children: [
                Text(l10n.quantity,
                    style: theme.textTheme.bodyLarge),
                const Spacer(),
                QuantityStepper(
                  value: _quantity,
                  min: 0,
                  onChanged: (v) => setState(() => _quantity = v),
                ),
              ],
            ),
            const SizedBox(height: 24),

            // Expiration date
            ExpiryDatePicker(
              value: _expirationDate,
              onChanged: (date) =>
                  setState(() => _expirationDate = date),
            ),
            const SizedBox(height: 24),

            // Storage location
            StorageLocationPicker(
              value: _storageLocationId,
              onChanged: (id) =>
                  setState(() => _storageLocationId = id),
            ),
            const SizedBox(height: 24),

            // Memo
            TextFormField(
              controller: _memoController,
              decoration: InputDecoration(
                labelText: '${l10n.memo} ${l10n.optional}',
                hintText: l10n.memoHint,
                border: const OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 32),

            // Action buttons
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: _isSaving ? null : () => context.pop(),
                    child: Text(l10n.cancel),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed: _isSaving ? null : _save,
                    child: _isSaving
                        ? const SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 2),
                          )
                        : Text(l10n.save),
                  ),
                ),
              ],
            ),

            // Delete button (edit mode only)
            if (widget.isEditMode) ...[
              const SizedBox(height: 24),
              Center(
                child: TextButton(
                  onPressed: _isSaving ? null : _deleteItem,
                  style: TextButton.styleFrom(
                    foregroundColor: theme.colorScheme.error,
                  ),
                  child: Text(l10n.deleteInventoryItem),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
