import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../../db/app_database.dart';
import '../../../l10n/generated/app_localizations.dart';
import '../../../providers/inventory_provider.dart';
import '../../../providers/storage_location_provider.dart';
import '../../../router/app_router.dart';
import '../../../widgets/quantity_stepper.dart';

/// A card widget that displays a single inventory item with quantity controls.
class InventoryItemCard extends ConsumerWidget {
  const InventoryItemCard({
    super.key,
    required this.item,
    required this.productId,
  });

  final InventoryItem item;
  final int productId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final dateFormat = DateFormat.yMd();

    final isExpired = item.expirationDate != null &&
        item.expirationDate!.isBefore(
          DateTime(
            DateTime.now().year,
            DateTime.now().month,
            DateTime.now().day,
          ),
        );

    return Card(
      child: InkWell(
        onTap: () {
          context.push(
            AppRoutes.inventoryEdit(productId.toString(), item.id.toString()),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Top row: quantity display + stepper
              Row(
                children: [
                  // Large quantity number
                  Text(
                    item.quantity.toString(),
                    style: theme.textTheme.headlineMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  const SizedBox(width: 4),
                  Text(
                    l10n.quantity,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const Spacer(),
                  // Compact stepper for quick adjustment
                  QuantityStepper(
                    value: item.quantity,
                    compact: true,
                    onChanged: (newQuantity) {
                      ref.read(inventoryActionsProvider).updateQuantity(
                            item.id,
                            productId,
                            newQuantity,
                          );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 12),

              // Expiration date
              Row(
                children: [
                  Icon(
                    Icons.event,
                    size: 16,
                    color: isExpired
                        ? theme.colorScheme.error
                        : theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 6),
                  if (item.expirationDate != null) ...[
                    Text(
                      dateFormat.format(item.expirationDate!),
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: isExpired ? theme.colorScheme.error : null,
                        fontWeight: isExpired ? FontWeight.bold : null,
                      ),
                    ),
                    if (isExpired) ...[
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.error,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          l10n.expiredStatus,
                          style: theme.textTheme.labelSmall?.copyWith(
                            color: theme.colorScheme.onError,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ] else
                    Text(
                      l10n.noExpiration,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 6),

              // Storage location
              if (item.storageLocationId != null)
                _StorageLocationLabel(
                  storageLocationId: item.storageLocationId!,
                ),

              // Memo
              if (item.memo != null && item.memo!.isNotEmpty) ...[
                const SizedBox(height: 8),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: theme.colorScheme.surfaceContainerHighest,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    item.memo!,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// Resolves a storage location id to its name using the provider.
class _StorageLocationLabel extends ConsumerWidget {
  const _StorageLocationLabel({required this.storageLocationId});

  final int storageLocationId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final locationsAsync = ref.watch(storageLocationsProvider);

    return locationsAsync.when(
      data: (locations) {
        final location = locations
            .where((l) => l.id == storageLocationId)
            .firstOrNull;
        if (location == null) return const SizedBox.shrink();

        return Row(
          children: [
            Icon(
              Icons.place,
              size: 16,
              color: theme.colorScheme.onSurfaceVariant,
            ),
            const SizedBox(width: 6),
            Text(
              location.name,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
          ],
        );
      },
      loading: () => const SizedBox.shrink(),
      error: (_, _) => const SizedBox.shrink(),
    );
  }
}
