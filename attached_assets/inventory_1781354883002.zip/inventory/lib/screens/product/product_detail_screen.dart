import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';

import '../../l10n/generated/app_localizations.dart';
import '../../providers/inventory_provider.dart';
import '../../providers/product_provider.dart';
import '../../router/app_router.dart';
import '../../widgets/delete_confirm_dialog.dart';
import 'widgets/inventory_item_card.dart';

/// Screen that displays product details and its inventory items.
class ProductDetailScreen extends ConsumerWidget {
  const ProductDetailScreen({super.key, required this.productId});

  final int productId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final productAsync = ref.watch(productByIdProvider(productId));
    final inventoryAsync =
        ref.watch(inventoryItemsByProductProvider(productId));

    return productAsync.when(
      data: (product) {
        if (product == null) {
          return Scaffold(
            appBar: AppBar(title: Text(l10n.productDetail)),
            body: const Center(child: CircularProgressIndicator()),
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: Text(product.name),
            actions: [
              IconButton(
                icon: const Icon(Icons.edit_outlined),
                tooltip: l10n.editProduct,
                onPressed: () => _showEditDialog(context, ref, product),
              ),
              IconButton(
                icon: const Icon(Icons.delete_outline),
                tooltip: l10n.deleteProduct,
                onPressed: () => _deleteProduct(context, ref, product),
              ),
            ],
          ),
          body: inventoryAsync.when(
            data: (items) {
              final totalQuantity =
                  items.fold<int>(0, (sum, item) => sum + item.quantity);

              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  // Product info card
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          if (product.barcode != null) ...[
                            Row(
                              children: [
                                Icon(
                                  Icons.qr_code,
                                  size: 18,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                                const SizedBox(width: 8),
                                Text(
                                  '${l10n.barcode}: ${product.barcode}',
                                  style: theme.textTheme.bodyMedium?.copyWith(
                                    color: theme.colorScheme.onSurfaceVariant,
                                  ),
                                ),
                              ],
                            ),
                            const SizedBox(height: 8),
                          ],
                          Row(
                            children: [
                              Icon(
                                Icons.calendar_today,
                                size: 18,
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                '${l10n.registeredDate}: ${DateFormat.yMd().format(product.createdAt)}',
                                style: theme.textTheme.bodyMedium?.copyWith(
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Total quantity summary
                  Row(
                    children: [
                      Text(
                        l10n.inventoryItems,
                        style: theme.textTheme.titleMedium,
                      ),
                      const Spacer(),
                      Text(
                        l10n.totalInventory(totalQuantity, items.length),
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),

                  // Add inventory button
                  OutlinedButton.icon(
                    onPressed: () {
                      context.push(
                        AppRoutes.inventoryNew(productId.toString()),
                      );
                    },
                    icon: const Icon(Icons.add),
                    label: Text(l10n.addInventory),
                  ),
                  const SizedBox(height: 12),

                  // Inventory items list
                  if (items.isEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 32),
                      child: Center(
                        child: Column(
                          children: [
                            Icon(
                              Icons.inventory_2_outlined,
                              size: 48,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            const SizedBox(height: 8),
                            Text(
                              l10n.noInventoryItems,
                              style: theme.textTheme.bodyLarge?.copyWith(
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              l10n.noInventoryItemsHint,
                              style: theme.textTheme.bodySmall?.copyWith(
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    ...items.map(
                      (item) => Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: InventoryItemCard(
                          item: item,
                          productId: productId,
                        ),
                      ),
                    ),
                ],
              );
            },
            loading: () =>
                const Center(child: CircularProgressIndicator()),
            error: (e, _) => Center(child: Text(e.toString())),
          ),
        );
      },
      loading: () => Scaffold(
        appBar: AppBar(title: Text(l10n.productDetail)),
        body: const Center(child: CircularProgressIndicator()),
      ),
      error: (e, _) => Scaffold(
        appBar: AppBar(title: Text(l10n.productDetail)),
        body: Center(child: Text(e.toString())),
      ),
    );
  }

  Future<void> _showEditDialog(
    BuildContext context,
    WidgetRef ref,
    dynamic product,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final nameController = TextEditingController(text: product.name);
    final barcodeController =
        TextEditingController(text: product.barcode ?? '');
    final formKey = GlobalKey<FormState>();

    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text(l10n.editProduct),
        content: Form(
          key: formKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextFormField(
                controller: nameController,
                decoration: InputDecoration(
                  labelText: l10n.productName,
                  border: const OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return l10n.productNameRequired;
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: barcodeController,
                decoration: InputDecoration(
                  labelText: '${l10n.barcode} ${l10n.optional}',
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.qr_code),
                ),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: Text(l10n.cancel),
          ),
          FilledButton(
            onPressed: () {
              if (formKey.currentState!.validate()) {
                Navigator.of(dialogContext).pop(true);
              }
            },
            child: Text(l10n.save),
          ),
        ],
      ),
    );

    if (confirmed == true && context.mounted) {
      final barcodeText = barcodeController.text.trim();
      await ref.read(productActionsProvider).update(
            id: product.id,
            name: nameController.text.trim(),
            barcode: barcodeText.isEmpty ? null : barcodeText,
            createdAt: product.createdAt,
          );

      if (context.mounted) {
        ref.invalidate(productByIdProvider(productId));
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.productUpdated)),
        );
      }
    }

    nameController.dispose();
    barcodeController.dispose();
  }

  Future<void> _deleteProduct(
    BuildContext context,
    WidgetRef ref,
    dynamic product,
  ) async {
    final l10n = AppLocalizations.of(context)!;
    final items = ref.read(inventoryItemsByProductProvider(productId));
    final inventoryCount = items.valueOrNull?.length ?? 0;

    final confirmed = await DeleteConfirmDialog.show(
      context,
      productName: product.name,
      inventoryCount: inventoryCount,
    );

    if (confirmed && context.mounted) {
      await ref.read(productActionsProvider).delete(product.id);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.productDeleted)),
        );
        context.go('/');
      }
    }
  }
}
