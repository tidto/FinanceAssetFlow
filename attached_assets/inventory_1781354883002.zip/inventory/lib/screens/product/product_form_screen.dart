import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../db/app_database.dart';
import '../../l10n/generated/app_localizations.dart';
import '../../providers/inventory_provider.dart';
import '../../providers/product_provider.dart';
import '../../widgets/expiry_date_picker.dart';
import '../../widgets/quantity_stepper.dart';
import '../../widgets/storage_location_picker.dart';

/// Screen for creating a new product (with optional barcode) or adding
/// inventory to an existing product found by barcode.
///
/// Entry paths:
/// 1. `/product/new?barcode=xxx` -- barcode scan, checks for existing product
/// 2. `/product/new` -- manual input, no barcode
/// 3. `/product/:id/edit` -- edit mode (Phase 8, structure prepared)
class ProductFormScreen extends ConsumerStatefulWidget {
  const ProductFormScreen({
    super.key,
    this.barcode,
    this.editProductId,
  });

  /// Barcode scanned before navigating here (may be null for manual input).
  final String? barcode;

  /// Product ID for edit mode (Phase 8). Null for new product creation.
  final int? editProductId;

  @override
  ConsumerState<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends ConsumerState<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();

  // Form fields
  late TextEditingController _nameController;
  late TextEditingController _memoController;
  int _quantity = 1;
  DateTime? _expirationDate;
  int? _storageLocationId;

  // State for barcode duplicate detection
  bool _isLoading = false;
  bool _isSaving = false;
  Product? _existingProduct;
  int _existingInventoryCount = 0;
  bool _showAddInventoryForm = false;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController();
    _memoController = TextEditingController();

    if (widget.barcode != null) {
      _lookupBarcode(widget.barcode!);
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _memoController.dispose();
    super.dispose();
  }

  Future<void> _lookupBarcode(String barcode) async {
    setState(() => _isLoading = true);
    try {
      final product = await ref.read(productByBarcodeProvider(barcode).future);
      if (product != null && mounted) {
        // Existing product found -- get inventory count
        final items = await ref
            .read(inventoryItemsByProductProvider(product.id).future);
        setState(() {
          _existingProduct = product;
          _existingInventoryCount = items.length;
          _isLoading = false;
        });
      } else if (mounted) {
        setState(() => _isLoading = false);
      }
    } catch (_) {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _saveNewProduct() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);
    try {
      final productActions = ref.read(productActionsProvider);
      final inventoryActions = ref.read(inventoryActionsProvider);

      // 1. Create product
      final productId = await productActions.create(
        name: _nameController.text.trim(),
        barcode: widget.barcode,
      );

      // 2. Create first inventory item
      await inventoryActions.create(
        productId: productId,
        quantity: _quantity,
        expirationDate: _expirationDate,
        storageLocationId: _storageLocationId,
        memo: _memoController.text.trim().isEmpty
            ? null
            : _memoController.text.trim(),
      );

      if (mounted) {
        final l10n = AppLocalizations.of(context)!;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.productSaved)),
        );
        context.go('/');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  Future<void> _addInventoryToExisting() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _isSaving = true);
    try {
      final inventoryActions = ref.read(inventoryActionsProvider);

      await inventoryActions.create(
        productId: _existingProduct!.id,
        quantity: _quantity,
        expirationDate: _expirationDate,
        storageLocationId: _storageLocationId,
        memo: _memoController.text.trim().isEmpty
            ? null
            : _memoController.text.trim(),
      );

      if (mounted) {
        final l10n = AppLocalizations.of(context)!;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(l10n.inventoryAdded)),
        );
        context.go('/');
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(e.toString())),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    if (_isLoading) {
      return Scaffold(
        appBar: AppBar(title: Text(l10n.newProduct)),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    // If an existing product was found by barcode
    if (_existingProduct != null) {
      return _buildExistingProductScreen(l10n);
    }

    // New product form
    return _buildNewProductScreen(l10n);
  }

  // ---------------------------------------------------------------------------
  // New product form
  // ---------------------------------------------------------------------------
  Widget _buildNewProductScreen(AppLocalizations l10n) {
    final hasBarcode = widget.barcode != null;

    return Scaffold(
      appBar: AppBar(title: Text(l10n.newProduct)),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Barcode field (read-only when provided)
            if (hasBarcode) ...[
              TextFormField(
                initialValue: widget.barcode,
                readOnly: true,
                decoration: InputDecoration(
                  labelText: l10n.barcode,
                  border: const OutlineInputBorder(),
                  prefixIcon: const Icon(Icons.qr_code),
                ),
              ),
              const SizedBox(height: 16),
            ],

            // Product name
            TextFormField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: l10n.productName,
                hintText: hasBarcode
                    ? l10n.productNameHint
                    : l10n.productNameManualHint,
                border: const OutlineInputBorder(),
              ),
              textInputAction: TextInputAction.next,
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return l10n.productNameRequired;
                }
                return null;
              },
            ),
            const SizedBox(height: 24),

            // First inventory info section header
            Text(
              l10n.firstInventoryInfo,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 12),

            // Quantity
            _buildQuantityRow(l10n),
            const SizedBox(height: 16),

            // Expiration date
            ExpiryDatePicker(
              value: _expirationDate,
              onChanged: (date) => setState(() => _expirationDate = date),
            ),
            const SizedBox(height: 16),

            // Storage location
            StorageLocationPicker(
              value: _storageLocationId,
              onChanged: (id) => setState(() => _storageLocationId = id),
            ),
            const SizedBox(height: 16),

            // Memo
            TextFormField(
              controller: _memoController,
              decoration: InputDecoration(
                labelText: '${l10n.memo} ${l10n.optional}',
                hintText: l10n.memoHint,
                border: const OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 24),

            // Buttons
            _buildActionButtons(l10n, onSave: _saveNewProduct),
          ],
        ),
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Existing product found (barcode duplicate)
  // ---------------------------------------------------------------------------
  Widget _buildExistingProductScreen(AppLocalizations l10n) {
    final product = _existingProduct!;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(l10n.newProduct)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Info banner
          Card(
            color: theme.colorScheme.primaryContainer,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Icon(
                    Icons.info_outline,
                    color: theme.colorScheme.onPrimaryContainer,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          l10n.existingProductFound,
                          style: theme.textTheme.titleSmall?.copyWith(
                            color: theme.colorScheme.onPrimaryContainer,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          product.name,
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: theme.colorScheme.onPrimaryContainer,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        if (product.barcode != null) ...[
                          const SizedBox(height: 2),
                          Text(
                            '${l10n.barcode}: ${product.barcode}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onPrimaryContainer,
                            ),
                          ),
                        ],
                        const SizedBox(height: 2),
                        Text(
                          l10n.currentInventoryCount(_existingInventoryCount),
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: theme.colorScheme.onPrimaryContainer,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          if (!_showAddInventoryForm) ...[
            // Show "Add Inventory" button
            FilledButton.icon(
              onPressed: () =>
                  setState(() => _showAddInventoryForm = true),
              icon: const Icon(Icons.add),
              label: Text(l10n.addInventory),
            ),
          ] else ...[
            // Inventory add form
            Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    l10n.newInventory,
                    style: theme.textTheme.titleMedium,
                  ),
                  const SizedBox(height: 12),

                  // Quantity
                  _buildQuantityRow(l10n),
                  const SizedBox(height: 16),

                  // Expiration date
                  ExpiryDatePicker(
                    value: _expirationDate,
                    onChanged: (date) =>
                        setState(() => _expirationDate = date),
                  ),
                  const SizedBox(height: 16),

                  // Storage location
                  StorageLocationPicker(
                    value: _storageLocationId,
                    onChanged: (id) =>
                        setState(() => _storageLocationId = id),
                  ),
                  const SizedBox(height: 16),

                  // Memo
                  TextFormField(
                    controller: _memoController,
                    decoration: InputDecoration(
                      labelText: '${l10n.memo} ${l10n.optional}',
                      hintText: l10n.memoHint,
                      border: const OutlineInputBorder(),
                      alignLabelWithHint: true,
                    ),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 24),

                  // Buttons
                  _buildActionButtons(
                    l10n,
                    onSave: _addInventoryToExisting,
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ---------------------------------------------------------------------------
  // Shared widgets
  // ---------------------------------------------------------------------------
  Widget _buildQuantityRow(AppLocalizations l10n) {
    return Row(
      children: [
        Text(l10n.quantity, style: Theme.of(context).textTheme.bodyLarge),
        const Spacer(),
        QuantityStepper(
          value: _quantity,
          min: 1,
          onChanged: (v) => setState(() => _quantity = v),
        ),
      ],
    );
  }

  Widget _buildActionButtons(
    AppLocalizations l10n, {
    required VoidCallback onSave,
  }) {
    return Row(
      children: [
        Expanded(
          child: OutlinedButton(
            onPressed: _isSaving ? null : () => context.pop(),
            child: Text(l10n.cancel),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: FilledButton(
            onPressed: _isSaving ? onSave : onSave,
            child: _isSaving
                ? const SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : Text(l10n.save),
          ),
        ),
      ],
    );
  }
}
