import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../l10n/generated/app_localizations.dart';
import '../../providers/product_provider.dart';
import '../../router/app_router.dart';
import '../../widgets/search_bar_widget.dart';
import 'widgets/empty_state.dart';
import 'widgets/expiry_alert_section.dart';
import 'widgets/product_card.dart';

/// The main home screen displaying the product list, expiry alerts,
/// and a search bar.
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  String _searchQuery = '';

  Future<void> _onBarcodeScan() async {
    final barcode = await context.push<String>(AppRoutes.scan);
    if (barcode == null || !mounted) return;

    final l10n = AppLocalizations.of(context)!;

    // Look up product by barcode.
    final product =
        await ref.read(productByBarcodeProvider(barcode).future);

    if (!mounted) return;

    if (product != null) {
      // Product found: navigate to detail.
      context.push(AppRoutes.productDetail('${product.id}'));
    } else {
      // Product not found: show snackbar and navigate to registration.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(l10n.productNotFoundRegister)),
      );
      context.push('${AppRoutes.productNew}?barcode=$barcode');
    }
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final productsAsync = ref.watch(productsWithQuantityProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.appTitle),
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
            child: SearchBarWidget(
              onChanged: (query) {
                setState(() {
                  _searchQuery = query;
                });
              },
              onScanPressed: _onBarcodeScan,
            ),
          ),
          // Content
          Expanded(
            child: productsAsync.when(
              loading: () => const Center(
                child: CircularProgressIndicator(),
              ),
              error: (error, stack) => Center(
                child: Text('$error'),
              ),
              data: (products) {
                // Filter by search query
                final filtered = _searchQuery.isEmpty
                    ? products
                    : products
                        .where((p) => p.product.name
                            .toLowerCase()
                            .contains(_searchQuery.toLowerCase()))
                        .toList();

                if (products.isEmpty) {
                  return const EmptyState();
                }

                return ListView(
                  children: [
                    // Expiry alert section (only when not searching)
                    if (_searchQuery.isEmpty)
                      const ExpiryAlertSection(),
                    // Products header
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                      child: Text(
                        _searchQuery.isEmpty
                            ? l10n.allProductsCount(filtered.length)
                            : l10n.searchResultsCount(filtered.length),
                        style:
                            Theme.of(context).textTheme.titleSmall?.copyWith(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceVariant,
                                ),
                      ),
                    ),
                    // No results message
                    if (filtered.isEmpty && _searchQuery.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.all(32),
                        child: Center(
                          child: Column(
                            children: [
                              Icon(
                                Icons.search_off,
                                size: 48,
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                              ),
                              const SizedBox(height: 12),
                              Text(
                                l10n.noSearchResults,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceVariant,
                                    ),
                              ),
                            ],
                          ),
                        ),
                      )
                    else
                      ...filtered.map(
                        (product) => ProductCard(
                          key: ValueKey(product.product.id),
                          data: product,
                          searchQuery:
                              _searchQuery.isNotEmpty ? _searchQuery : null,
                        ),
                      ),
                    // Bottom padding for FAB
                    const SizedBox(height: 80),
                  ],
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _showAddMethodSheet(context),
        tooltip: l10n.addProduct,
        child: const Icon(Icons.add),
      ),
    );
  }

  void _showAddMethodSheet(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                // Title
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: Text(
                    l10n.addProduct,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                // Barcode scan option
                _AddMethodOption(
                  icon: Icons.qr_code_scanner,
                  title: l10n.barcodeScan,
                  description: l10n.scanToRegister,
                  onTap: () async {
                    Navigator.pop(sheetContext);
                    final barcode =
                        await context.push<String>(AppRoutes.scan);
                    if (barcode != null && context.mounted) {
                      // Registration mode: navigate to new product with barcode
                      context.push(
                        '${AppRoutes.productNew}?barcode=$barcode',
                      );
                    }
                  },
                ),
                const SizedBox(height: 8),
                // Manual input option
                _AddMethodOption(
                  icon: Icons.edit_outlined,
                  title: l10n.manualInput,
                  description: l10n.manualInputDescription,
                  onTap: () {
                    Navigator.pop(sheetContext);
                    context.push(AppRoutes.productNew);
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _AddMethodOption extends StatelessWidget {
  const _AddMethodOption({
    required this.icon,
    required this.title,
    required this.description,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String description;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: EdgeInsets.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  icon,
                  color: theme.colorScheme.onPrimaryContainer,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.titleSmall?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      description,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
