import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../db/daos/product_dao.dart';
import '../../../l10n/generated/app_localizations.dart';
import '../../../router/app_router.dart';
import '../../../utils/highlight_text.dart';

/// A card displaying a product's name and total quantity.
/// Tapping navigates to the product detail screen.
class ProductCard extends StatelessWidget {
  const ProductCard({
    super.key,
    required this.data,
    this.searchQuery,
  });

  final ProductWithTotalQuantity data;

  /// When provided, matching portions of the product name are highlighted.
  final String? searchQuery;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final product = data.product;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      child: InkWell(
        onTap: () => context.push(AppRoutes.productDetail('${product.id}')),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          child: Row(
            children: [
              // Product info
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildProductName(theme),
                    if (product.barcode != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        '${l10n.barcode}: ${product.barcode}',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: 12),
              // Quantity badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: theme.colorScheme.primaryContainer,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${data.totalQuantity}',
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: theme.colorScheme.onPrimaryContainer,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProductName(ThemeData theme) {
    final baseStyle = theme.textTheme.titleSmall?.copyWith(
      fontWeight: FontWeight.w600,
    );

    final query = searchQuery ?? '';
    if (query.isEmpty) {
      return Text(
        data.product.name,
        style: baseStyle,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      );
    }

    return RichText(
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      text: TextSpan(
        children: highlightText(
          text: data.product.name,
          query: query,
          baseStyle: baseStyle,
        ),
      ),
    );
  }
}
