import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../db/app_database.dart';
import '../../../l10n/generated/app_localizations.dart';
import '../../../providers/inventory_provider.dart';
import '../../../providers/product_provider.dart';
import '../../../router/app_router.dart';
import '../../../theme/app_theme.dart';

/// Displays a warning section for expired and expiring-soon inventory items.
/// Only visible when there are items to warn about.
class ExpiryAlertSection extends ConsumerWidget {
  const ExpiryAlertSection({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final expiredAsync = ref.watch(expiredItemsProvider);
    final expiringAsync = ref.watch(expiringItemsProvider);

    final expiredItems = expiredAsync.valueOrNull ?? [];
    final expiringItems = expiringAsync.valueOrNull ?? [];

    if (expiredItems.isEmpty && expiringItems.isEmpty) {
      return const SizedBox.shrink();
    }

    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Section header
          Row(
            children: [
              Icon(
                Icons.warning_rounded,
                color: theme.colorScheme.error,
                size: 20,
              ),
              const SizedBox(width: 6),
              Text(
                l10n.expirationWarning,
                style: theme.textTheme.titleSmall?.copyWith(
                  color: theme.colorScheme.error,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Alert items list
          ...expiredItems.map(
            (item) => _ExpiryAlertItem(
              item: item,
              isExpired: true,
            ),
          ),
          ...expiringItems.map(
            (item) => _ExpiryAlertItem(
              item: item,
              isExpired: false,
            ),
          ),
        ],
      ),
    );
  }
}

class _ExpiryAlertItem extends ConsumerWidget {
  const _ExpiryAlertItem({
    required this.item,
    required this.isExpired,
  });

  final InventoryItem item;
  final bool isExpired;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final l10n = AppLocalizations.of(context)!;
    final theme = Theme.of(context);
    final warningColors = theme.extension<WarningColors>()!;
    final productAsync = ref.watch(productByIdProvider(item.productId));
    final productName = productAsync.valueOrNull?.name ?? '...';

    // Calculate D-day
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);

    String badgeText;
    Color badgeBg;
    Color badgeText_;
    Color badgeBorder;

    if (isExpired) {
      badgeText = l10n.expiredStatus;
      badgeBg = const Color(0xFFFEF2F2);
      badgeText_ = const Color(0xFFDC2626);
      badgeBorder = const Color(0xFFFCA5A5);
    } else {
      final expirationDate = item.expirationDate!;
      final expDate = DateTime(
        expirationDate.year,
        expirationDate.month,
        expirationDate.day,
      );
      final daysLeft = expDate.difference(today).inDays;
      badgeText = l10n.dDay(daysLeft);
      badgeBg = warningColors.warningLight;
      badgeText_ = const Color(0xFF92400E);
      badgeBorder = warningColors.warningBorder;
    }

    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: InkWell(
        onTap: () =>
            context.push(AppRoutes.productDetail('${item.productId}')),
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: isExpired
                ? const Color(0xFFFEF2F2)
                : warningColors.warningLight,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: isExpired
                  ? const Color(0xFFFCA5A5)
                  : warningColors.warningBorder,
              width: 0.5,
            ),
          ),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      productName,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        fontWeight: FontWeight.w500,
                      ),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                    ),
                    Text(
                      '${l10n.quantity}: ${item.quantity}',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              // Badge
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 8,
                  vertical: 3,
                ),
                decoration: BoxDecoration(
                  color: badgeBg,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: badgeBorder, width: 0.5),
                ),
                child: Text(
                  badgeText,
                  style: theme.textTheme.labelSmall?.copyWith(
                    color: badgeText_,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
