import 'package:flutter/material.dart';

/// A semi-transparent overlay with a transparent rectangular cutout in the
/// centre, plus decorative corner guides.
class ScanOverlay extends StatelessWidget {
  const ScanOverlay({
    super.key,
    this.scanAreaSize = 280.0,
    this.cornerLength = 32.0,
    this.cornerStrokeWidth = 4.0,
  });

  /// Side length of the transparent scan area (square).
  final double scanAreaSize;

  /// Length of each corner guide line.
  final double cornerLength;

  /// Stroke width of the corner guide lines.
  final double cornerStrokeWidth;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final width = constraints.maxWidth;
        final height = constraints.maxHeight;
        final left = (width - scanAreaSize) / 2;
        final top = (height - scanAreaSize) / 2;

        return Stack(
          children: [
            // Semi-transparent background with cut-out
            CustomPaint(
              size: Size(width, height),
              painter: _OverlayPainter(
                scanRect: Rect.fromLTWH(left, top, scanAreaSize, scanAreaSize),
              ),
            ),
            // Corner guides
            Positioned(
              left: left,
              top: top,
              child: CustomPaint(
                size: Size(scanAreaSize, scanAreaSize),
                painter: _CornerPainter(
                  cornerLength: cornerLength,
                  strokeWidth: cornerStrokeWidth,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// Paints a semi-transparent overlay with a transparent rectangular hole.
class _OverlayPainter extends CustomPainter {
  _OverlayPainter({required this.scanRect});

  final Rect scanRect;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black.withValues(alpha: 0.6);

    // Draw the full overlay, then cut out the scan area.
    final fullRect = Rect.fromLTWH(0, 0, size.width, size.height);
    final path = Path()
      ..addRect(fullRect)
      ..addRRect(RRect.fromRectAndRadius(scanRect, const Radius.circular(12)))
      ..fillType = PathFillType.evenOdd;

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(_OverlayPainter oldDelegate) =>
      oldDelegate.scanRect != scanRect;
}

/// Paints four decorative corner guides around the scan area.
class _CornerPainter extends CustomPainter {
  _CornerPainter({
    required this.cornerLength,
    required this.strokeWidth,
    required this.color,
  });

  final double cornerLength;
  final double strokeWidth;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = strokeWidth
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final w = size.width;
    final h = size.height;
    final cl = cornerLength;

    // Top-left
    canvas.drawLine(Offset(0, cl), Offset.zero, paint);
    canvas.drawLine(Offset.zero, Offset(cl, 0), paint);

    // Top-right
    canvas.drawLine(Offset(w - cl, 0), Offset(w, 0), paint);
    canvas.drawLine(Offset(w, 0), Offset(w, cl), paint);

    // Bottom-left
    canvas.drawLine(Offset(0, h - cl), Offset(0, h), paint);
    canvas.drawLine(Offset(0, h), Offset(cl, h), paint);

    // Bottom-right
    canvas.drawLine(Offset(w - cl, h), Offset(w, h), paint);
    canvas.drawLine(Offset(w, h - cl), Offset(w, h), paint);
  }

  @override
  bool shouldRepaint(_CornerPainter oldDelegate) =>
      oldDelegate.cornerLength != cornerLength ||
      oldDelegate.strokeWidth != strokeWidth ||
      oldDelegate.color != color;
}
