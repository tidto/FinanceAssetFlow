import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import '../../l10n/generated/app_localizations.dart';
import 'widgets/scan_overlay.dart';

/// Full-screen barcode scanner screen.
///
/// Returns the scanned barcode value via [Navigator.pop] / [context.pop].
/// The calling screen decides how to handle the result (register vs search).
class BarcodeScanScreen extends StatefulWidget {
  const BarcodeScanScreen({super.key});

  @override
  State<BarcodeScanScreen> createState() => _BarcodeScanScreenState();
}

class _BarcodeScanScreenState extends State<BarcodeScanScreen> {
  final MobileScannerController _controller = MobileScannerController();
  bool _hasScanned = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_hasScanned) return;
    final barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;

    final value = barcodes.first.rawValue;
    if (value == null || value.isEmpty) return;

    setState(() {
      _hasScanned = true;
    });
    _controller.stop();
    context.pop(value);
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: Colors.black,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
        title: Text(
          l10n.barcodeScan,
          style: const TextStyle(color: Colors.white),
        ),
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          // Camera view
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            errorBuilder: (context, error, child) {
              return _ScannerErrorWidget(error: error);
            },
          ),
          // Scan guide overlay
          const ScanOverlay(),
          // Bottom hint text
          Positioned(
            left: 0,
            right: 0,
            bottom: 120,
            child: Text(
              l10n.scannerHint,
              textAlign: TextAlign.center,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 16,
                fontWeight: FontWeight.w500,
                shadows: [
                  Shadow(
                    blurRadius: 4,
                    color: Colors.black54,
                  ),
                ],
              ),
            ),
          ),
          // Manual input link at bottom
          Positioned(
            left: 0,
            right: 0,
            bottom: 60,
            child: Center(
              child: TextButton(
                onPressed: () => _showManualInputDialog(context),
                child: Text(
                  l10n.enterBarcodeManually,
                  style: TextStyle(
                    color: Colors.white.withValues(alpha: 0.8),
                    fontSize: 14,
                    decoration: TextDecoration.underline,
                    decorationColor: Colors.white.withValues(alpha: 0.8),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showManualInputDialog(BuildContext context) async {
    final l10n = AppLocalizations.of(context)!;
    final textController = TextEditingController();

    final value = await showDialog<String>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: Text(l10n.enterBarcodeManually),
          content: TextField(
            controller: textController,
            autofocus: true,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              hintText: l10n.barcodeNumberOrSkip,
              border: const OutlineInputBorder(),
            ),
            onSubmitted: (v) {
              if (v.isNotEmpty) {
                Navigator.pop(dialogContext, v);
              }
            },
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: Text(l10n.cancel),
            ),
            FilledButton(
              onPressed: () {
                final v = textController.text.trim();
                if (v.isNotEmpty) {
                  Navigator.pop(dialogContext, v);
                }
              },
              child: Text(l10n.save),
            ),
          ],
        );
      },
    );

    if (value != null && value.isNotEmpty && mounted) {
      if (context.mounted) {
        context.pop(value);
      }
    }
  }
}

/// Widget shown when the scanner encounters an error (e.g. permission denied,
/// no camera available).
class _ScannerErrorWidget extends StatelessWidget {
  const _ScannerErrorWidget({required this.error});

  final MobileScannerException error;

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    final isPermissionError =
        error.errorCode == MobileScannerErrorCode.permissionDenied;

    final message = isPermissionError
        ? l10n.cameraPermissionDenied
        : l10n.cameraNotAvailable;

    return Container(
      color: Colors.black,
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                isPermissionError ? Icons.no_photography : Icons.videocam_off,
                size: 64,
                color: Colors.white54,
              ),
              const SizedBox(height: 24),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
              if (isPermissionError) ...[
                const SizedBox(height: 24),
                OutlinedButton.icon(
                  onPressed: () {
                    // openAppSettings via mobile_scanner is not directly
                    // available, so we use the system channel approach.
                    // On most platforms MobileScanner will prompt again on
                    // re-open, or the user can go to OS settings manually.
                    _openSettings(context);
                  },
                  icon: const Icon(Icons.settings, color: Colors.white70),
                  label: Text(
                    l10n.goToSettings,
                    style: const TextStyle(color: Colors.white),
                  ),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.white54),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 24,
                      vertical: 12,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openSettings(BuildContext context) async {
    // Try using the platform-specific app settings opener.
    // mobile_scanner does not expose openAppSettings directly,
    // but we can attempt to use the WidgetsBinding to open settings
    // via intent on Android / URL scheme on iOS.
    // For a production app, the `app_settings` or `permission_handler`
    // package would be used. Here we pop back and let the user know.
    if (context.mounted) {
      context.pop();
    }
  }
}
