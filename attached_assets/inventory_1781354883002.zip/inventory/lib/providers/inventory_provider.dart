import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../db/daos/inventory_item_dao.dart';
import 'app_setting_provider.dart';
import 'database_provider.dart';
import 'product_provider.dart';

/// Stream provider family: inventory items for a given product.
final inventoryItemsByProductProvider =
    StreamProvider.family<List<InventoryItem>, int>((ref, productId) {
  final dao = ref.watch(inventoryItemDaoProvider);
  return dao.getItemsByProductId(productId);
});

/// Stream provider: items expiring within alert_days from today.
/// Depends on [expirationAlertDaysProvider] for the threshold.
final expiringItemsProvider = StreamProvider<List<InventoryItem>>((ref) {
  final alertDays = ref.watch(expirationAlertDaysProvider);
  final dao = ref.watch(inventoryItemDaoProvider);
  return alertDays.when(
    data: (days) => dao.getExpiringItems(days),
    loading: () => const Stream.empty(),
    error: (_, _) => const Stream.empty(),
  );
});

/// Stream provider: already-expired items (expiration_date < today).
final expiredItemsProvider = StreamProvider<List<InventoryItem>>((ref) {
  final dao = ref.watch(inventoryItemDaoProvider);
  return dao.getExpiredItems();
});

/// Notifier for inventory item CRUD and quantity actions.
final inventoryActionsProvider = Provider<InventoryActions>((ref) {
  return InventoryActions(ref);
});

class InventoryActions {
  final Ref _ref;

  InventoryActions(this._ref);

  InventoryItemDao get _dao => _ref.read(inventoryItemDaoProvider);

  Future<int> create({
    required int productId,
    required int quantity,
    DateTime? expirationDate,
    int? storageLocationId,
    String? memo,
  }) async {
    final now = DateTime.now();
    final id = await _dao.insertItem(
      InventoryItemsCompanion.insert(
        productId: productId,
        quantity: Value(quantity),
        expirationDate: Value(expirationDate),
        storageLocationId: Value(storageLocationId),
        memo: Value(memo),
        createdAt: now,
        updatedAt: now,
      ),
    );
    _invalidate(productId);
    return id;
  }

  Future<bool> update({
    required int id,
    required int productId,
    required int quantity,
    DateTime? expirationDate,
    int? storageLocationId,
    String? memo,
    required DateTime createdAt,
  }) async {
    final now = DateTime.now();
    final result = await _dao.updateItem(
      InventoryItemsCompanion(
        id: Value(id),
        productId: Value(productId),
        quantity: Value(quantity),
        expirationDate: Value(expirationDate),
        storageLocationId: Value(storageLocationId),
        memo: Value(memo),
        createdAt: Value(createdAt),
        updatedAt: Value(now),
      ),
    );
    _invalidate(productId);
    return result;
  }

  Future<bool> updateQuantity(int id, int productId, int quantity) async {
    final result = await _dao.updateQuantity(id, quantity);
    _invalidate(productId);
    return result;
  }

  Future<bool> incrementQuantity(
      int id, int productId, int currentQuantity) async {
    return updateQuantity(id, productId, currentQuantity + 1);
  }

  Future<bool> decrementQuantity(
      int id, int productId, int currentQuantity) async {
    if (currentQuantity <= 0) return false;
    return updateQuantity(id, productId, currentQuantity - 1);
  }

  Future<int> delete(int id, int productId) async {
    final result = await _dao.deleteItem(id);
    _invalidate(productId);
    return result;
  }

  void _invalidate(int productId) {
    _ref.invalidate(inventoryItemsByProductProvider(productId));
    _ref.invalidate(productsWithQuantityProvider);
    _ref.invalidate(expiringItemsProvider);
    _ref.invalidate(expiredItemsProvider);
  }
}
