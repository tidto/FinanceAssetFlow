import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../db/daos/app_setting_dao.dart';
import '../db/daos/inventory_item_dao.dart';
import '../db/daos/product_dao.dart';
import '../db/daos/storage_location_dao.dart';

/// AppDatabase singleton provider.
/// Uses manual Provider (not @riverpod) because the DB must live
/// for the entire app lifecycle.
final databaseProvider = Provider<AppDatabase>((ref) => AppDatabase());

final productDaoProvider = Provider<ProductDao>((ref) {
  return ref.watch(databaseProvider).productDao;
});

final inventoryItemDaoProvider = Provider<InventoryItemDao>((ref) {
  return ref.watch(databaseProvider).inventoryItemDao;
});

final storageLocationDaoProvider = Provider<StorageLocationDao>((ref) {
  return ref.watch(databaseProvider).storageLocationDao;
});

final appSettingDaoProvider = Provider<AppSettingDao>((ref) {
  return ref.watch(databaseProvider).appSettingDao;
});
