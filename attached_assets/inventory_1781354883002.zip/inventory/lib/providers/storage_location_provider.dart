import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import 'database_provider.dart';

/// Stream provider: all storage locations ordered by id.
final storageLocationsProvider =
    StreamProvider<List<StorageLocation>>((ref) {
  final dao = ref.watch(storageLocationDaoProvider);
  return dao.getAllLocations();
});

/// Actions for storage location management.
final storageLocationActionsProvider =
    Provider<StorageLocationActions>((ref) {
  return StorageLocationActions(ref);
});

class StorageLocationActions {
  final Ref _ref;

  StorageLocationActions(this._ref);

  Future<int> create(String name) async {
    final dao = _ref.read(storageLocationDaoProvider);
    final id = await dao.insertLocation(name);
    _ref.invalidate(storageLocationsProvider);
    return id;
  }

  Future<int> delete(int id) async {
    final dao = _ref.read(storageLocationDaoProvider);
    final result = await dao.deleteLocation(id);
    _ref.invalidate(storageLocationsProvider);
    return result;
  }
}
