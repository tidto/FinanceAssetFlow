import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'database_provider.dart';

/// The default number of days before expiration to show an alert.
const _defaultAlertDays = 3;

/// Provider: expiration alert days setting.
/// Returns the integer value from app_settings, defaulting to 3.
final expirationAlertDaysProvider = FutureProvider<int>((ref) async {
  final dao = ref.watch(appSettingDaoProvider);
  final value = await dao.getValue('expiration_alert_days');
  if (value == null) return _defaultAlertDays;
  return int.tryParse(value) ?? _defaultAlertDays;
});

/// Actions for app settings management.
final appSettingActionsProvider = Provider<AppSettingActions>((ref) {
  return AppSettingActions(ref);
});

class AppSettingActions {
  final Ref _ref;

  AppSettingActions(this._ref);

  Future<void> setExpirationAlertDays(int days) async {
    final dao = _ref.read(appSettingDaoProvider);
    await dao.setValue('expiration_alert_days', days.toString());
    _ref.invalidate(expirationAlertDaysProvider);
  }

  Future<String?> getValue(String key) async {
    final dao = _ref.read(appSettingDaoProvider);
    return dao.getValue(key);
  }

  Future<void> setValue(String key, String value) async {
    final dao = _ref.read(appSettingDaoProvider);
    await dao.setValue(key, value);
  }
}
