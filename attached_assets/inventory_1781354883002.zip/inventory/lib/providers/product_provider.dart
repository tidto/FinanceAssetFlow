import 'package:drift/drift.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../db/app_database.dart';
import '../db/daos/product_dao.dart';
import 'database_provider.dart';

/// Stream provider: all products with their total inventory quantity.
final productsWithQuantityProvider =
    StreamProvider<List<ProductWithTotalQuantity>>((ref) {
  final dao = ref.watch(productDaoProvider);
  return dao.getProductsWithTotalQuantity();
});

/// Future provider family: single product by id.
final productByIdProvider =
    FutureProvider.family<Product?, int>((ref, id) {
  final dao = ref.watch(productDaoProvider);
  return dao.getProductById(id);
});

/// Future provider family: product lookup by barcode.
final productByBarcodeProvider =
    FutureProvider.family<Product?, String>((ref, barcode) {
  final dao = ref.watch(productDaoProvider);
  return dao.getProductByBarcode(barcode);
});

/// Future provider family: search products by name.
final searchProductsProvider =
    FutureProvider.family<List<Product>, String>((ref, query) {
  final dao = ref.watch(productDaoProvider);
  return dao.searchProductsByName(query);
});

/// Notifier for product CRUD actions.
/// Call methods on this provider to create/update/delete products,
/// then invalidate relevant providers so the UI refreshes.
final productActionsProvider = Provider<ProductActions>((ref) {
  return ProductActions(ref);
});

class ProductActions {
  final Ref _ref;

  ProductActions(this._ref);

  ProductDao get _dao => _ref.read(productDaoProvider);

  Future<int> create({
    required String name,
    String? barcode,
  }) async {
    final now = DateTime.now();
    final id = await _dao.insertProduct(
      ProductsCompanion.insert(
        name: name,
        barcode: Value(barcode),
        createdAt: now,
        updatedAt: now,
      ),
    );
    _invalidate();
    return id;
  }

  Future<bool> update({
    required int id,
    required String name,
    String? barcode,
    required DateTime createdAt,
  }) async {
    final now = DateTime.now();
    final result = await _dao.updateProduct(
      ProductsCompanion(
        id: Value(id),
        name: Value(name),
        barcode: Value(barcode),
        createdAt: Value(createdAt),
        updatedAt: Value(now),
      ),
    );
    _invalidate();
    _ref.invalidate(productByIdProvider(id));
    return result;
  }

  Future<int> delete(int id) async {
    final result = await _dao.deleteProduct(id);
    _invalidate();
    return result;
  }

  void _invalidate() {
    _ref.invalidate(productsWithQuantityProvider);
  }
}
