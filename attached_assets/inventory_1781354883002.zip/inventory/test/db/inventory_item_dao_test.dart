import 'package:drift/drift.dart' hide isNull, isNotNull;
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:inventory/db/app_database.dart';

void main() {
  late AppDatabase db;
  late int productId;

  setUp(() async {
    db = AppDatabase.forTesting(NativeDatabase.memory());

    // Create a product for inventory items
    final now = DateTime.now();
    productId = await db.productDao.insertProduct(
      ProductsCompanion.insert(
        name: '테스트 상품',
        createdAt: now,
        updatedAt: now,
      ),
    );
  });

  tearDown(() async {
    await db.close();
  });

  group('T-DB-04. InventoryItems DAO', () {
    test('재고 항목 생성 후 id 반환 확인', () async {
      final now = DateTime.now();
      final id = await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      expect(id, isPositive);
    });

    test('상품 id로 재고 목록 조회 - 해당 상품의 항목만 반환', () async {
      final now = DateTime.now();

      // Create another product
      final otherProductId = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '다른 상품',
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Insert items for the first product
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Insert item for another product
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: otherProductId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final items =
          await db.inventoryItemDao.getItemsByProductId(productId).first;

      expect(items, hasLength(2));
      for (final item in items) {
        expect(item.productId, equals(productId));
      }
    });

    test('수량 업데이트 후 조회 확인', () async {
      final now = DateTime.now();
      final id = await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Default quantity is 1, update to 5
      final success = await db.inventoryItemDao.updateQuantity(id, 5);
      expect(success, isTrue);

      final item = await db.inventoryItemDao.getItemById(id);
      expect(item, isNotNull);
      expect(item!.quantity, equals(5));
    });

    test('사용기한 임박 조회 - 기준일 이내 항목만 반환', () async {
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);

      // Item expiring in 2 days (within alert window of 3)
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(1),
          expirationDate: Value(today.add(const Duration(days: 2))),
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Item expiring in 10 days (outside alert window)
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(1),
          expirationDate: Value(today.add(const Duration(days: 10))),
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Item already expired (should NOT appear in expiring, only in expired)
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(1),
          expirationDate: Value(today.subtract(const Duration(days: 1))),
          createdAt: now,
          updatedAt: now,
        ),
      );

      final expiringItems =
          await db.inventoryItemDao.getExpiringItems(3).first;

      expect(expiringItems, hasLength(1));
      expect(
        expiringItems.first.expirationDate,
        equals(today.add(const Duration(days: 2))),
      );
    });

    test('사용기한 만료 조회 - 오늘 이전 항목만 반환', () async {
      final now = DateTime.now();
      final today = DateTime(now.year, now.month, now.day);

      // Expired item
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(1),
          expirationDate: Value(today.subtract(const Duration(days: 1))),
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Not expired item
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(1),
          expirationDate: Value(today.add(const Duration(days: 5))),
          createdAt: now,
          updatedAt: now,
        ),
      );

      final expiredItems = await db.inventoryItemDao.getExpiredItems().first;

      expect(expiredItems, hasLength(1));
      expect(
        expiredItems.first.expirationDate!.isBefore(today),
        isTrue,
      );
    });

    test('사용기한 null(무기한) 항목은 임박/만료 조회에서 제외', () async {
      final now = DateTime.now();

      // Item with no expiration date
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(1),
          createdAt: now,
          updatedAt: now,
        ),
      );

      final expiringItems =
          await db.inventoryItemDao.getExpiringItems(3).first;
      final expiredItems = await db.inventoryItemDao.getExpiredItems().first;

      expect(expiringItems, isEmpty);
      expect(expiredItems, isEmpty);
    });

    test('재고 항목 삭제 확인', () async {
      final now = DateTime.now();
      final id = await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      final deletedCount = await db.inventoryItemDao.deleteItem(id);
      expect(deletedCount, equals(1));

      final item = await db.inventoryItemDao.getItemById(id);
      expect(item, isNull);
    });

    test('수량 0 허용 확인', () async {
      final now = DateTime.now();
      final id = await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          quantity: const Value(0),
          createdAt: now,
          updatedAt: now,
        ),
      );

      final item = await db.inventoryItemDao.getItemById(id);
      expect(item, isNotNull);
      expect(item!.quantity, equals(0));
    });

    test('수량 음수 불허 (CHECK 제약) 확인', () async {
      final now = DateTime.now();

      expect(
        () => db.inventoryItemDao.insertItem(
          InventoryItemsCompanion.insert(
            productId: productId,
            quantity: const Value(-1),
            createdAt: now,
            updatedAt: now,
          ),
        ),
        throwsA(isA<Exception>()),
      );
    });
  });
}
