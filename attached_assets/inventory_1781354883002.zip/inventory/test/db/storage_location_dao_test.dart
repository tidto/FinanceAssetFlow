import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:inventory/db/app_database.dart';

void main() {
  late AppDatabase db;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() async {
    await db.close();
  });

  group('T-DB-05. StorageLocations DAO', () {
    test('전체 목록 조회 - 28건 반환', () async {
      final locations = await db.storageLocationDao.getAllLocations().first;
      expect(locations, hasLength(28));
    });

    test('위치 추가 후 목록에 포함 확인', () async {
      final newId = await db.storageLocationDao.insertLocation('새로운 장소');

      expect(newId, isPositive);

      final locations = await db.storageLocationDao.getAllLocations().first;
      expect(locations, hasLength(29));

      final names = locations.map((l) => l.name).toList();
      expect(names, contains('새로운 장소'));
    });

    test('동일 이름 중복 추가 시 UNIQUE 위반 에러 확인', () async {
      // '냉장고' is already in seed data
      expect(
        () => db.storageLocationDao.insertLocation('냉장고'),
        throwsA(isA<Exception>()),
      );
    });
  });
}
