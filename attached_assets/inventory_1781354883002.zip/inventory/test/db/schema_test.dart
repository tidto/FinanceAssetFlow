import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:inventory/db/app_database.dart';

void main() {
  late AppDatabase db;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() async {
    await db.close();
  });

  group('T-DB-01. 테이블 생성 및 스키마 검증', () {
    test('DB 초기화 시 4개 테이블 생성 확인', () async {
      // Force DB open by executing a query
      final tables = await db
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'",
          )
          .get();

      final tableNames = tables.map((row) => row.read<String>('name')).toSet();

      expect(tableNames, contains('products'));
      expect(tableNames, contains('inventory_items'));
      expect(tableNames, contains('storage_locations'));
      expect(tableNames, contains('app_settings'));
    });

    test('인덱스 생성 확인', () async {
      final indexes = await db
          .customSelect(
            "SELECT name FROM sqlite_master WHERE type='index'",
          )
          .get();

      final indexNames =
          indexes.map((row) => row.read<String>('name')).toList();

      // UNIQUE constraints on products.barcode and storage_locations.name
      // create automatic indexes
      expect(indexNames, isNotEmpty);
    });

    test('FK 제약 및 CASCADE 동작 확인', () async {
      // FK should be enabled
      final fkResult =
          await db.customSelect('PRAGMA foreign_keys').getSingle();
      expect(fkResult.read<int>('foreign_keys'), equals(1));

      // Insert a product
      final now = DateTime.now();
      final productId = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '테스트 상품',
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Insert an inventory item linked to the product
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Verify inventory item exists
      final itemsBefore =
          await db.inventoryItemDao.getItemsByProductId(productId).first;
      expect(itemsBefore, hasLength(1));

      // Delete the product - should CASCADE delete inventory items
      await db.productDao.deleteProduct(productId);

      // Verify inventory item is also deleted
      final itemsAfter =
          await db.inventoryItemDao.getItemsByProductId(productId).first;
      expect(itemsAfter, isEmpty);
    });
  });

  group('T-DB-02. Seed 데이터', () {
    test('초기화 후 storage_locations 28건 삽입 확인', () async {
      final locations = await db.storageLocationDao.getAllLocations().first;
      expect(locations, hasLength(28));
    });

    test('초기화 후 app_settings에 expiration_alert_days = 3 존재 확인', () async {
      final value = await db.appSettingDao.getValue('expiration_alert_days');
      expect(value, equals('3'));
    });

    test('두 번째 초기화 시 중복 삽입되지 않음 확인', () async {
      // The seed data runs only in onCreate, so a second open
      // of the same in-memory DB won't re-run it.
      // We verify the current counts are correct (not doubled).
      final locations = await db.storageLocationDao.getAllLocations().first;
      expect(locations, hasLength(28));

      final value = await db.appSettingDao.getValue('expiration_alert_days');
      expect(value, equals('3'));
    });
  });
}
