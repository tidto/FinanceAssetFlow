import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:inventory/db/app_database.dart';

void main() {
  late AppDatabase db;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() async {
    await db.close();
  });

  group('T-DB-06. AppSettings DAO', () {
    test('key로 값 읽기 확인', () async {
      final value = await db.appSettingDao.getValue('expiration_alert_days');
      expect(value, equals('3'));
    });

    test('존재하지 않는 key -> null 반환', () async {
      final value = await db.appSettingDao.getValue('non_existent_key');
      expect(value, isNull);
    });

    test('값 쓰기 (upsert) 확인', () async {
      // Update existing key
      await db.appSettingDao.setValue('expiration_alert_days', '7');
      final updatedValue =
          await db.appSettingDao.getValue('expiration_alert_days');
      expect(updatedValue, equals('7'));

      // Insert new key
      await db.appSettingDao.setValue('theme_mode', 'dark');
      final newValue = await db.appSettingDao.getValue('theme_mode');
      expect(newValue, equals('dark'));
    });
  });
}
