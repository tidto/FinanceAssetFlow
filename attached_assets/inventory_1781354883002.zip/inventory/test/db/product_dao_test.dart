import 'package:drift/drift.dart' hide isNull, isNotNull;
import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:inventory/db/app_database.dart';

void main() {
  late AppDatabase db;

  setUp(() {
    db = AppDatabase.forTesting(NativeDatabase.memory());
  });

  tearDown(() async {
    await db.close();
  });

  DateTime currentTime() => DateTime.now();

  group('T-DB-03. Products DAO', () {
    test('상품 생성 후 id 반환 확인', () async {
      final now = currentTime();
      final id = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '서울우유 1L',
          createdAt: now,
          updatedAt: now,
        ),
      );

      expect(id, isPositive);
    });

    test('바코드로 조회 - 존재하는 바코드 -> 상품 반환', () async {
      final now = currentTime();
      await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '서울우유 1L',
          barcode: Value('8801234567890'),
          createdAt: now,
          updatedAt: now,
        ),
      );

      final product =
          await db.productDao.getProductByBarcode('8801234567890');

      expect(product, isNotNull);
      expect(product!.name, equals('서울우유 1L'));
      expect(product.barcode, equals('8801234567890'));
    });

    test('바코드로 조회 - 존재하지 않는 바코드 -> null 반환', () async {
      final product =
          await db.productDao.getProductByBarcode('0000000000000');

      expect(product, isNull);
    });

    test('이름 부분 일치 검색 - "우유" 입력 시 "서울우유 1L" 매칭', () async {
      final now = currentTime();
      await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '서울우유 1L',
          createdAt: now,
          updatedAt: now,
        ),
      );
      await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '치약',
          createdAt: now,
          updatedAt: now,
        ),
      );

      final results = await db.productDao.searchProductsByName('우유');

      expect(results, hasLength(1));
      expect(results.first.name, equals('서울우유 1L'));
    });

    test('이름 검색 - 결과 없을 때 빈 리스트 반환', () async {
      final now = currentTime();
      await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '치약',
          createdAt: now,
          updatedAt: now,
        ),
      );

      final results = await db.productDao.searchProductsByName('없는상품');

      expect(results, isEmpty);
    });

    test('상품 수정 (이름 변경) 후 조회 확인', () async {
      final now = currentTime();
      final id = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '서울우유 1L',
          createdAt: now,
          updatedAt: now,
        ),
      );

      final updated = await db.productDao.updateProduct(
        ProductsCompanion(
          id: Value(id),
          name: const Value('매일우유 1L'),
          barcode: const Value(null),
          createdAt: Value(now),
          updatedAt: Value(currentTime()),
        ),
      );

      expect(updated, isTrue);

      final product = await db.productDao.getProductById(id);
      expect(product, isNotNull);
      expect(product!.name, equals('매일우유 1L'));
    });

    test('상품 삭제 시 연결된 inventory_items CASCADE 삭제 확인', () async {
      final now = currentTime();
      final productId = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '서울우유 1L',
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Add inventory items
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );
      await db.inventoryItemDao.insertItem(
        InventoryItemsCompanion.insert(
          productId: productId,
          createdAt: now,
          updatedAt: now,
        ),
      );

      // Verify items exist
      final itemsBefore =
          await db.inventoryItemDao.getItemsByProductId(productId).first;
      expect(itemsBefore, hasLength(2));

      // Delete product
      await db.productDao.deleteProduct(productId);

      // Verify items are also deleted via CASCADE
      final itemsAfter =
          await db.inventoryItemDao.getItemsByProductId(productId).first;
      expect(itemsAfter, isEmpty);
    });

    test('동일 바코드 중복 생성 시 UNIQUE 위반 에러 확인', () async {
      final now = currentTime();
      await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '서울우유 1L',
          barcode: Value('8801234567890'),
          createdAt: now,
          updatedAt: now,
        ),
      );

      expect(
        () => db.productDao.insertProduct(
          ProductsCompanion.insert(
            name: '매일우유 1L',
            barcode: Value('8801234567890'),
            createdAt: now,
            updatedAt: now,
          ),
        ),
        throwsA(isA<Exception>()),
      );
    });

    test('바코드 null인 상품 여러 개 생성 가능 확인', () async {
      final now = currentTime();
      final id1 = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '바코드 없는 상품 1',
          createdAt: now,
          updatedAt: now,
        ),
      );
      final id2 = await db.productDao.insertProduct(
        ProductsCompanion.insert(
          name: '바코드 없는 상품 2',
          createdAt: now,
          updatedAt: now,
        ),
      );

      expect(id1, isPositive);
      expect(id2, isPositive);
      expect(id1, isNot(equals(id2)));
    });
  });
}
